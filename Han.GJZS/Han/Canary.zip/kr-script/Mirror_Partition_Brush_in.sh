#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


[[ $IMG = '请选择分区：' ]] && abort "！选择分区哈"
IFS=$'\n'
e=${IMG##*/}
if [[ -z $Brush_in ]]; then
   Brush_in=/storage/emulated/0/"$IMG".img
fi

echo "您当前选择了$e分区"
echo
echo "刷入文件路径为$Brush_in"
echo

CQ2() {
   if [[ $ChongQi2 == 1 ]]; then
      echo "即将重启到恢复模式，倒计时开始……"
      for i in $(seq 4 -1 1); do
      echo $i
      sleep 1
      done
      reboot recovery
   fi
}

echo "- 开始刷写$e分区"
echo "- 开始检测刷入镜像文件是否存在…………"
echo
[[ ! -L $IMG ]] && abort "！$e分区不存在无法刷入"
   if [[ -f $Brush_in ]]; then
      echo "$Brush_in刷入文件存在，开始刷入…………"
      dd if="$Brush_in" of="$IMG" && CQ && CQ2
   else
      abort "$Brush_in刷入文件都不存在，怎么刷？？？"
   fi
sleep 2