#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


mask -v
Dir=$Modules_Dir/Automatic_protective_charging 
XinXI=$Modules_Dir/Automatic_protective_charging/module.prop
script=$Modules_Dir/Automatic_protective_charging/service.sh
script2=$Modules_Dir/Automatic_protective_charging/Charging_control4.sh
echo "Stop=$Stop" > $Data_Dir/Charging_control4.log
echo "Start=$Start" >> $Data_Dir/Charging_control4.log
echo "Set_Greedy_Time=$Set_Greedy_Time" >> $Data_Dir/Charging_control4.log
echo "Delay=$Delay" >> $Data_Dir/Charging_control4.log
echo "ChongQi=$ChongQi" >> $Data_Dir/Charging_control4.log


if [[ -x $Magisk && -f $Charging_control || -x $Magisk && -f $Charging_control2 ]]; then
   echo "已检测到您安装了Magisk $MAGISK_VER（$MAGISK_VER_CODE），且已支持您的设备"
   if [[ $Stop -lt 100 ]]; then
      description="由「搞机助手」生成的自动充电保护模块，大于或等于$Stop停止充电，低于或等于$Start才能允许充电，不需要可随时卸载重启即可恢复。"
   elif [[ $Stop -eq 100 ]]; then
      description="由「搞机助手」生成的自动充电保护模块，等于$Stop停止充电，低于或等于$Start才能允许充电，不需要可随时卸载重启即可恢复。"
   fi
elif [[ ! -x $Magisk ]]; then
   error "已检测到您没有安装Magisk Manager，无法使用功能"
   abort "后会有期……"
elif [[ -x $Magisk && ! -f $Charging_control || -x $Magisk && ! -f $Charging_control2 ]]; then
   error "已检测到您安装了Magisk Manager，但目前没有适配你的机型，您可以在关于里通过私信我寻求适配"
   abort "后会有期……"
fi

[[ ! -d $Dir ]] && mkdir -p $Dir
rm -f $Dir/*
[[ $MAGISK_VER_CODE -lt 18100 ]] && touch $Dir/auto_mount && echo 已创建auto_mount

cat <<Han >$script
#!/system/bin/sh
$Magisk su -c 'sh $script2'
Han

cat <<Han >$script2
#!/system/bin/sh
#作者  by：Han | 情非得已c
#本模块由「搞机助手」创建、URL=https://www.coolapk.com/apk/Han.GJZS
#特别鸣谢：topjohnwu
#本模块需要Magisk提供服务支持


Charging_control=$Charging_control
Charging_control2=$Charging_control2
Start=$Start
Stop=$Stop
Delay=$Delay
Set_Greedy_Time=$Set_Greedy_Time
export PATH="$PATH0:/sbin/.magisk/busybox"
unset L H
awk 'BEGIN{print "success"}'
[[ \$? -ne 0 ]] && exit 1
[[ ! -f \$Charging_control && ! -f \$Charging_control2 ]] && exit 1

{
sleep 1m
until false; do
   [[ -n \$Delay ]] && sleep \$Delay
   Status=\`[[ -f \$Charging_control ]] && cat \$Charging_control\`
   Status2=\`[[ -f \$Charging_control2 ]] && cat \$Charging_control2\`
   if [[ \$(dumpsys battery|awk '/level/{print \$2}') -ge \$Stop ]]; then
      if [[ \$Status -eq 0 || \$Status2 -eq 1 ]]; then
         if [[ -n \$L ]]; then
            L=\$L
         elif [[ -z \$L ]]; then
            [[ -n \$Set_Greedy_Time ]] && sleep \$Set_Greedy_Time
            [[ -f \$Charging_control ]] && echo 1 >\$Charging_control
            [[ -f \$Charging_control2 ]] && echo 0 >\$Charging_control2
            L=1
            unset H
         fi
      fi
   elif [[ \$(dumpsys battery|awk '/level/{print \$2}') -le \$Start ]]; then
      if [[ \$Status -eq 1 || \$Status2 -eq 0 ]]; then
         if [[ -n \$H ]]; then
            H=\$H
         elif [[ -z \$H ]]; then
            [[ -f \$Charging_control ]] && echo 0 >\$Charging_control
            [[ -f \$Charging_control2 ]] && echo 1 >\$Charging_control2
            H=1
            unset L
         fi
      fi
   fi
done
}&
Han

printf "id=Automatic_protective_charging 
name=方案④全自动充电保护
version=v2020070800
versionCode=6
author=by：Han  情非得已c
description=$description" >$XinXI

[[ -f $script ]] && echo "Magisk模块创建完成，模块将在下次重启后生效"
CQ