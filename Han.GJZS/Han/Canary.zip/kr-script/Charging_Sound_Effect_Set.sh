#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Mount_system
lu=$PeiZhi_File/MIUI
wj=$lu/$Sound/*
jian=$audio/charging.ogg
jian2=$audio/disconnect.ogg
jian3=$audio/charging.ogg.bak
jian4=$audio/disconnect.ogg.bak
Choice=1


case $Sound in
0)
echo "正在恢复默认……"
   if [[ -f $jian3 ]]; then mv $jian3 $jian; echo "已恢复插入充电音效"; fi
   if [[ -f $jian4 ]]; then mv $jian4 $jian2; echo "已恢复移除充电音效"; fi
   sleep 3
   exit 0
   ;;

c)
if [[ -f "$ZiDY_Effect" ]]; then
if [[ ! -f $jian3 ]]; then
echo "正在备份原插入充电音效."
mv $jian $jian3
fi
cp -f "$ZiDY_Effect" $jian && echo "已自定义${ZiDY_Effect##*/}为插入音效。"
chmod 644 $jian &>/dev/null
Unload
sleep 3
exit 0
fi
;;

d)
if [[ -f "$ZiDY_Effect" ]]; then
   if [[ ! -f $jian4 ]]; then
echo "正在备份原拔出充电音效.."
mv $jian2 $jian4
   fi
cp -f "$ZiDY_Effect" $jian2 && echo "已自定义${ZiDY_Effect##*/}为拔出音效。"
chmod 644 $jian2 &>/dev/null
Unload
sleep 3
exit 0
fi
;;
esac

. $Load Charging_Sound_Effect


[[ ! -d $lu ]] && mkdir -p $lu
Dir=`ls -l $lu |grep "^d"|wc -l`

   if [[ $Dir != 5 ]]; then
echo "正在解压……"
unzip -oq "$Download_File" -d $lu
   fi
      if [[ ! -f $jian3 ]]; then
      echo "正在备份原插入充电音效."
      mv $jian $jian3
      fi
         if [[ ! -f $jian4 ]]; then
      echo "正在备份原移除充电音效.."
      mv $jian2 $jian4
         fi

List=`ls $lu`
      if [[ -n "$1" ]]; then
echo "开始安装……"
cp -f $wj $audio
chmod 644 $audio/{charging,disconnect}.ogg &>/dev/null
Unload
sleep 4
      else
echo "文件不存在无法安装"
      fi
