#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


case $Option in
1)
for i in $File_Dir; do
   chattr +i "$i"
   [[ $? = 0 ]] && echo "已保护了$i" && echo "$i" >>$Data_Dir/Protection_File_Dir.log
done
;;
0)
for i in $File_Dir; do
   chattr -i "$i"
   [[ $? = 0 ]] && echo "已解除了对$i的保护"
done
;;
esac