#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

modules_uninstall=/data/adb/modules/Model_Camouflage

if [[ -d $modules_uninstall ]]; then
echo "已检测到您安装了机型伪装模块，即将为您卸载"
rm -rf $modules_uninstall && echo "卸载成功"
elif [[ ! -d $modules_uninstall ]]; then
echo "没有检测到您安装了机型伪装模块哈！"
fi