#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Canary=`grep_prop Canary $data_MD5`

V() {
    echo "设备架构：$ABI"
    if [[ -f $Data_Dir/busybox_Installed.log ]]; then
       echo "命令版本：`cat $Data_Dir/Applet_Installed.log`（`cat $Data_Dir/busybox_Installed.log`）"
    else
       echo "命令版本：`cat $Data_Dir/Applet_Installed.log`"
    fi
    echo -e "\n\n$1版本：$Version_Name（$Version_code）更新日志如下:"
    . $Load Update_Log -apk
}

V2() {
    echo "$1版云端页面：`cat $Data_Dir/Cloud_Version.log`"
    echo "更新日志如下："
    . $Load Update_Log -log
    echo -e "\n\n-------------------------------------------------------\n"
}

kuan() {
    echo "URL=https://www.coolapk.com/apk/Han.GJZS"
    Website https://www.coolapk.com/apk/Han.GJZS
    exit $?
}

Update() {
    if [[ $Version_code -lt $7 ]]; then
       echo "！已检测到最新版本：${3%.*}（$7），正在跳转到酷安网页更新"
       kuan
    elif [[ $Version_code -eq $Canary ]]; then
       V2 内测
    elif [[ $Version_code -eq $7 ]]; then
       V2 正式
    elif [[ $Version_code -lt $Canary ]]; then
        echo "！已发布了最新内测版本请前往「搞机助手」内测群里更新"
        exit 1
    else
        echo "！未知版本"
        exit 1
    fi
}


    if [[ ! -s $Load || ! -f $data_MD5 ]]; then
        echo "！连接服务器失败❌，部分功能已无法使用" 1>&2
        exit 1
    fi
    . $Load Update


Update() {
    if [[ $Version_code -eq $Canary ]]; then
       V 内测
    elif [[ $Version_code -eq $7 ]]; then
       V 正式
    fi
}


    . $Load Update
