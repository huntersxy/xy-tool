#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

echo -e "`{ cd /data/misc/wifi;[ -f WifiConfigStore.xml ] && egrep '"SS|"Pre' WifiConfigStore.xml || egrep -A 1 'ssid=' wpa_supplicant.conf;} | sed '/ssid=[^"]/s/\([0-9a-f]\{2\}\)/\\x\1/g;/^--/d;s/"//g;s/&quot;//g;s/<\/.*//g;s/<n.*/t=/g;s/.*D>/d=/g;s/.*y>/k=/g;s/.*d=/\nWiFi网络名称: /g;s/.*k=/WiFi密码: /g;s/.*t=.*/WiFi密码: 无/g'`"
