#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


if [[ -d /version/special_cust/BLN-TL10C752/cmcc/cn/media ]]; then
    echo horror
elif [[ -d /system/media ]]; then
    echo Android_Default
elif [[ -d /system/product/media ]]; then
    echo Android_10
elif [[ -d /system/media/theme/bootup ]]; then
    echo nubia
elif [[ -d /product/etc/media ]]; then
    echo HuaWei
fi