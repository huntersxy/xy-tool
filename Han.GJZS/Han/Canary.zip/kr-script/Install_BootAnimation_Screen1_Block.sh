#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


. ./Block_Device_Name.sh -None

sed -n '/\/splash|splash/p; /\/logo|logo/p' $jian
