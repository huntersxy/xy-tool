#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Tu=/data/system/theme/$1
if [[ -f $Tu ]]; then
   case $1 in
   wallpaper)
   echo "- 正在提取桌面壁纸"
   File=$GJZS/桌面壁纸$Time.png
   ;;
   
   lock_wallpaper)
   echo "- 正在提取锁屏壁纸"
   File=$GJZS/锁屏壁纸$Time.png
   ;;
   esac
   cp -f $Tu $File
else
   abort "！未找到$2壁纸"
fi

echo "- 文件输出路径：\"$File\"  "
sleep 3