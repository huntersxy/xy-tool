#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


[[ -z "$IMG" ]] && abort "！分区都不选打包空气？？？"
device=`getprop ro.product.device`
version=`getprop ro.build.version.incremental`
TMP=$Dir/$device-${version}-${Type}-by_Han_${Time}
[[ ! -d $TMP ]] && mkdir -p $TMP

Update_Magisk() {
Download "$@"
}


if [[ $Type = Card_Brush ]]; then
   Script_Dir=$TMP/META-INF/com/google/android
   [[ ! -d $Script_Dir ]] && mkdir -p $Script_Dir
   Script="$TMP/META-INF/com/google/android/updater-script"
   ScriptB="$TMP/META-INF/com/google/android/update-binary"
   
   echo "- 已选择卡刷模式"

cat <<Han >$ScriptB
#!/sbin/sh
#by Han　|　情非得已c
#搞机助手下载地址：https://www.coolapk.com/apk/Han.GJZS

umask 022
OUTFD="\$2"
ZIPFILE="\$3"
Dir=/tmp/Han.GJZS
device=\`getprop ro.product.device\`

ui_print() {
   echo "ui_print "\$@"" > /proc/self/fd/\$OUTFD
}

Han
      if [[ $Verify = 1 ]]; then
         echo "- 已添加机型验证，别的机型无法刷入此包"
         echo
         echo
cat <<Han >>$ScriptB
if [[ \$device != "$device" ]]; then
   ui_print "此卡刷包只适配 \"$device\" 设备; 您的设备是：\$device"
   exit 1
fi

Han
      fi
cat <<Han >>$ScriptB
ui_print "- 本卡刷包由「搞机助手」打包而成"
ui_print
ui_print "- by Han　|　情非得已c"
ui_print "- 下载地址：https://www.coolapk.com/apk/Han.GJZS"
ui_print

mkdir -p "\$Dir"
unzip -o "\$ZIPFILE" '*.img' -d "\$Dir"
Han
      
      
      for i in $IMG; do
         e=${i##*/}
         echo "- 正在提取$e分区……"
         dd if="$i" of="$TMP/$e".img
cat <<Han >>$ScriptB
ui_print "- 正在刷写$e分区……"
dd if="\$Dir/$e.img" of="$i" &>/dev/null
ui_print
Han
      done

            if [[ $ROOT = 1 ]]; then
               echo "- 正在往卡刷包里添加Magisk……"
               [[ -f $Load ]] && . $Load Update_Magisk
               Update_Magisk() {
               [[ ! -d $TMP/Han.GJZS ]] && mkdir -p $TMP/Han.GJZS
               cp -f $Download_File $TMP/Han.GJZS/Magisk.zip
   
cat <<Han >>$ScriptB
ui_print "- 开始安装 $2..."
unzip -oq "\$ZIPFILE" 'Han.GJZS/Magisk.zip' -d "\$Dir"
unzip -oq "\$Dir/Han.GJZS/Magisk.zip" 'META-INF/com/google/android/update-binary' -d "\$Dir"
sh "\$Dir/META-INF/com/google/android/update-binary" dummy 1 "\$Dir/Han.GJZS/Magisk.zip"
Han
               }
               [[ -f $Load ]] && . $Load Update_Magisk
            fi

elif [[ $Type = Wire_Brush ]]; then
   Script="$TMP/flash_all.sh"
   TMP2=$TMP/images
   [[ ! -d $TMP2 ]] && mkdir -p $TMP2
   echo "- 已选择线刷模式"
cat <<Han >$Script
#!/system/bin/sh

#by Han　|　情非得已c
#搞机助手下载地址：https://www.coolapk.com/apk/Han.GJZS

echo "- 本线刷包由「搞机助手」打包而成"
echo
echo "- by Han　|　情非得已c"
echo "- 下载地址：https://www.coolapk.com/apk/Han.GJZS"
echo
Han

      if [[ $Verify = 1 ]]; then
         echo "- 已添加机型验证，别的机型无法刷入此包"
         echo
         echo
cat <<Han >>$Script
fastboot getvar product 2>&1 | grep "^product: *$device$"
   if [ \$? -ne 0 ] ; then echo "您的设备不是$device，无法刷入"; exit 1; fi

Han
      fi
         for i in $IMG; do
            e=${i##*/}
            echo "- 正在提取$e分区……"
            dd if="$i" of="$TMP/$e".img
cat <<Han >>$Script
echo "- 正在刷写$e分区……"
fastboot flash $e \`dirname \$0\`/images/${e}.img
echo
Han
         done

cat <<Han >>$Script
echo "- 正在重启手机"
fastboot reboot
echo "- 线刷完成"
echo "- 用时$SECONDS秒"
Han
fi

   echo
   echo "- 开始打包ROM为zip格式……"
   File="${TMP}.zip"
   cd $TMP
   zip -r "$File" ./*
      if [[ $? = 0 ]]; then
         echo "打包成功"
         rm -r $TMP
         cd $ShellScript
         if [[ $Type = Card_Brush ]]; then
            echo "- 开始签名卡刷包"
            . ./Zipsigner.sh
            [[ $? -eq 0 ]] && rm -f "$File"
         fi
      else
         rm -f ${TMP}.zip
         error "！自动打包失败！！！"
         abort "！请前往$TMP目录里用其它压缩软件，压缩成zip格式，打包$TMP目录里的所有文件即可"
      fi
