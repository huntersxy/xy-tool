#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Update_Magisk() {
    Download "$@"
}


. $Load Update_Magisk
cp -rf "$Download_File" "$File_Dir"
echo
echo "- 已下载到$File_Dir/$File_Name"
