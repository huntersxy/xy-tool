#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


# check android
if [[ $SDK -lt 23 ]]; then
  abort "! 不支持的 sdk版本: $SDK"
else
  ui_print "- 当前设备 sdk: $SDK"
fi

# check architecture
abi_Detection
if [ "$ARCH" != "arm" ] && [ "$ARCH" != "arm64" ] && [ "$ARCH" != "x86" ] && [ "$ARCH" != "x64" ]; then
  abort "! 不支持的设备架构: $ARCH"
else
  ui_print "- 当前设备架构: $ARCH"
fi

Choice=1

. $Load riru-core

customize() {

mkdir -p "$RIRU_PATH/modules"
mkdir -p "$RIRU_PATH/bin"
set_perm "$RIRU_PATH" 0 0 0700
set_perm "$RIRU_PATH/modules" 0 0 0700
set_perm "$RIRU_PATH/bin" 0 0 0700
cp -f $MODPATH/zygote_restart/zygote_restart_$ARCH $RIRU_PATH/bin/zygote_restart
set_perm "$RIRU_PATH/bin/zygote_restart" 0 0 0700


echo -n "$RIRU_API" > "$RIRU_PATH/api_version.new"
echo -n "$RIRU_VERSION_NAME" > "$RIRU_PATH/version_name.new"
echo -n "$RIRU_VERSION_CODE" > "$RIRU_PATH/version_code.new"
set_perm "$RIRU_PATH/api_version.new" 0 0 0600
set_perm "$RIRU_PATH/version_name.new" 0 0 0600
set_perm "$RIRU_PATH/version_code.new" 0 0 0600
#[[ -f $RIRU_PATH/api_version.new ]] && cp -af $RIRU_PATH/{api_version.new,api_version} || echo "$RIRU_API" >$RIRU_PATH/api_version
#set_perm "$RIRU_PATH/api_version" 0 0 0600

set_perm_recursive "$MODPATH" 0 0 0755 0644
}

Mount_system
ZIPFILE="$Download_File"
if [[ -f "$ZIPFILE" ]]; then
echo "---------------------------------------------------------"
echo "开始安装 "${3##*/}"……"
[[ -d $Script_Dir ]] && rm -rf $Script_Dir &>/dev/null
[[ ! -d $Script_Dir ]] && mkdir -p $Script_Dir
unzip -ojq "$ZIPFILE" "module.prop" -d $Script_Dir
   if [[ -f $Script_Dir/module.prop ]]; then
MODID=$(grep_prop id $Script_Dir/module.prop)
Name=$(grep_prop name $Script_Dir/module.prop)
      if [[ -n $MODID ]]; then
printf "开始植入$Name至系统
---------------------------------------------------------
"
MODPATH=$Frame_Dir/$MODID
[[ -d $MODPATH ]] && rm -rf $MODPATH
[[ ! -d $MODPATH ]] && mkdir -p $MODPATH
abi_Detection
  unzip -oq "$ZIPFILE" -x "*.sha256sum" "META-INF/*" -d "$MODPATH" 2>/dev/null
         if [[ "$ARCH" == "x86" || "$ARCH" == "x64" ]]; then
  rm -r $MODPATH/system
  mv "$MODPATH/system_x86" "$MODPATH/system"
         fi

            if [[ "$IS64BIT" == "false" ]]; then
  echo "- 删除64位库"
  rm -rf "$MODPATH/system/lib64"
            else
$IS64BIT && rm -r $MODPATH/system_x86
            fi
RIRU_API=`grep_prop RIRU_API $MODPATH/customize.sh | tr -d \"`
RIRU_PATH=`grep_prop RIRU_PATH $MODPATH/customize.sh | tr -d \"`
RIRU_VERSION_CODE=`grep_prop RIRU_VERSION_CODE $MODPATH/customize.sh | tr -d \"`
RIRU_VERSION_NAME=`grep_prop RIRU_VERSION_NAME $MODPATH/customize.sh | tr -d \"`

customize

File=/system/lib/libmemtrack.so
File2=/system/lib/libmemtrack_real.so
File3=/system/lib64/libmemtrack.so
File4=/system/lib64/libmemtrack_real.so
[[ -f "$File" && ! -f $File2 ]] && cp -f "$File" "${MODPATH}$File2"
[[ -f "$File3" && ! -f $File4 ]] && cp -f "$File3" "${MODPATH}$File4"

End_installation
      else
      echo "未找到id信息无法安装"
      fi
   fi
rm -rf $Script_Dir &>/dev/null
fi


Unload
ChongQi=1
End_of_Frame_installation
