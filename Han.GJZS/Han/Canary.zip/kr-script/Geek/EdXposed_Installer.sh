#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Version=Stable
if [[ ! -f "/data/misc/riru/api_version" && ! -f "/data/misc/riru/api_version.new" ]]; then
    error "*********************************************************"
    error "！未安装Riru - Core 框架，安装失败！！！"
    abort "*********************************************************"
fi

Inject_prop() {
    local IFS=$'\n'
    
    for i in `cat $MODPATH/system.prop`; do
        if ! fgrep -q "$i" $system/build.prop; then
            echo "$i" >>$system/build.prop
        fi
    done
}

check_architecture() {
    if [[ "${MODID}" == "riru_edxposed_sandhook" ]]; then
        VARIANTS="SandHook"
    else
        VARIANTS="YAHFA"
    fi
        if [[ "${ARCH}" != "arm" && "${ARCH}" != "arm64" && "${ARCH}" != "x86" && "${ARCH}" != "x64" ]]; then
            abort "! 不支持的平台是 ${ARCH}"
        else
            echo "- 当前设备平台是 ${ARCH}"
                if [[ "${ARCH}" == "x86" || "${ARCH}" == "x64" ]]; then
                    if [[ "${VARIANTS}" == "SandHook" ]]; then
                    echo "******************************"
                    echo "! 检测到架构x86或x86 64"
                    echo "! 仅YAHFA版本支持x86或x86 64体系结构设备"
                    abort    "******************************"
                fi
        fi
    fi
}

Clean_Residue() {
    touch $Frame_Dir/$1/remove &>/dev/null
    . "$Frame_remove_Set"
}

AZ_EdXp_apk() {
    . $Core
    Download "$@"
    export File="$Download_File"
        if [[ -f $File ]]; then
            pm uninstall org.meowcat.edxposed.manager &>/dev/null
            echo "开始安装$3……"
            sh $ShellScript/install_apk.sh
        else
            error "下载$3失败❌"
        fi
}

#
if [[ $SDK -lt 26 ]]; then
    echo "******************************"
    echo "! 检测到旧版Android $SDK（在Oreo以下）"
    echo "! 在Android 8.0下只能使用原始的Xposed框架"
    echo "! 您可以从“ Xposed安装程序”或“ Magisk Manager（无系统安装）”中下载"
    echo "! Learn more: https://github.com/ElderDrivers/EdXposed/wiki/Available-Android-versions"
    abort "******************************"
fi

    if [[ -d /data/data/com.solohsu.android.edxp.manager ]]; then echo -e "已检测到您安装了EdXposed Installer，由于作者没更新了导致无法检测到新版EDXposed，显示未安装！\n请卸载EdXposed Installer选择EdXposed_Manager才能继续安装"; exit 1; fi


Frame_Dir=/data/misc/Han.GJZS
[[ ! -d $Frame_Dir ]] && mkdir -p $Frame_Dir
Clean_Residue riru_edxposed
Clean_Residue riru_edxposed_sandhook

if [[ $EdXp_Type -eq Custom ]]; then
    ZDY=1
else

    if [[ $Version = Canary ]]; then
        if [[ $EdXp_Type -eq 1 ]]; then
        YAHFA=1
        echo "已选择Canary-YAHFA版EdXposed"
        elif [[ $EdXp_Type -eq 2 ]]; then
        echo "已选择Canary-SandHook版EdXposed"
        SandHook=1
        fi
    elif [[ $Version = Stable ]]; then
        if [[ $EdXp_Type -eq 1 ]]; then
            Stable_YAHFA=1
            echo "已选择稳定版YAHFA版EdXposed"
        elif [[ $EdXp_Type -eq 2 ]]; then
            echo "已选择稳定版SandHook版EdXposed"
            Stable_SandHook=1
        fi
    fi
fi

apk2=$apk
apk=0
ChongQi=$ChongQi2

. $Load EdXposed

Mount_system
abi_Detection
    if [[ $ZDY -eq 1 ]]; then
        ZIPFILE="$File"
    else
        ZIPFILE="$Download_File"
    fi
    
        if [[ -f "$ZIPFILE" ]]; then
            echo "---------------------------------------------------------"
            echo "开始安装 "${2##*/}"……"
            [[ -d $Script_Dir ]] && rm -rf $Script_Dir &>/dev/null
            [[ ! -d $Script_Dir ]] && mkdir -p $Script_Dir
            unzip -ojq "$ZIPFILE" "module.prop" -d $Script_Dir
                if [[ -f $Script_Dir/module.prop ]]; then
                MODID=$(grep_prop id $Script_Dir/module.prop)
                Name=$(grep_prop name $Script_Dir/module.prop)
                    if [[ -n $MODID ]]; then
                        if [[ $ZDY = 1 ]]; then
                            case $MODID in
                            riru_edxposed) :;;
                            riru_edxposed_sandhook) :;;
                            *) abort "您选择的自定义模块文件不是EDXposed-Magisk文件，不允许被刷入，后会有期……886";;
                            esac
                        fi
                        echo "开始植入$Name至系统"
                        echo "---------------------------------------------------------"
                        check_architecture
                        MODPATH=$Frame_Dir/$MODID
                        [[ -d $MODPATH ]] && rm -rf $MODPATH
                        [[ ! -d $MODPATH ]] && mkdir -p $MODPATH
                            unzip -oq "$ZIPFILE" -x "*.sha256sum" "META-INF/*" -d "$MODPATH" 2>/dev/null
                                if [[ "$ARCH" == "x86" || "$ARCH" == "x64" ]]; then
                                    rm -r $MODPATH/system
                                    mv "$MODPATH/system_x86" "$MODPATH/system"
                                fi
                                
                                    if [[ "$IS64BIT" == "false" ]]; then
                                        echo "- 删除64位库"
                                        rm -rf "$MODPATH/system/lib64"
                                    else
                                        $IS64BIT && rm -r $MODPATH/system_x86
                                    fi
                                        RIRU_PATH=`grep_prop RIRU_PATH $MODPATH/customize.sh | tr -d \"`
                                        EDXP_LU=$RIRU_PATH/modules/edxp
                                        
                                        [[ ! -d $EDXP_LU ]] && mkdir -p $EDXP_LU
                                        cp -f $MODPATH/module.prop $EDXP_LU
                                        Inject_prop
                                        set_perm_recursive "${MODPATH}" 0 0 0755 0644
                                        Write_Record $MODID
                                        End_installation
                    else
                        error "未找到id信息无法安装"
                        ChongQi=0
                    fi
                fi
                rm -rf $Script_Dir &>/dev/null
        fi


apk=$apk2
unset YAHFA SandHook Stable_YAHFA Stable_SandHook
. $Load EdXposed

Unload
End_of_Frame_installation
CQ