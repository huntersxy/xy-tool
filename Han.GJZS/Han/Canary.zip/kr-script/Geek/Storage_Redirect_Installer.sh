#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


if [[ ! -f "/data/misc/riru/api_version" && ! -f "/data/misc/riru/api_version.new" ]]; then
error "*********************************************************"
error "！未安装Riru - Core 框架，安装失败！！！"
abort "*********************************************************"
elif [[ ! -d /data/data/moe.shizuku.redirectstorage ]]; then
abort "！没有安装存储重定向应用，无法安装"
fi

Choice=1
. $Load riru_storage_redirect

RIRU_PATH="/data/misc/riru"
TMPDIR=$Script_Dir
alias sha256sum="$ELF2_Path/sha256sum"

Mount_system
ZIPFILE="$PeiZhi_File/$3"
if [[ -f "$ZIPFILE" ]]; then
[[ -d $Script_Dir ]] && rm -rf $Script_Dir &>/dev/null
[[ ! -d $Script_Dir ]] && mkdir -p $Script_Dir
echo "---------------------------------------------------------"
unzip -ojq "$ZIPFILE" "customize.sh" "module.prop" -d $Script_Dir
if [[ -f $Script_Dir/module.prop ]]; then
Name=$(grep_prop name $Script_Dir/module.prop)
MODID=$(grep_prop id $Script_Dir/module.prop)
if [[ -n $MODID ]]; then
printf "开始安装$Name
---------------------------------------------------------
"
echo "正在安装……"
abi_Detection
MODPATH=$Frame_Dir/$MODID
[[ -d $MODPATH ]] && rm -rf $MODPATH
[[ ! -d $MODPATH ]] && mkdir -p $MODPATH

. $Script_Dir/customize.sh 2>/dev/null
sh $MODPATH/post-fs-data.sh
Write_Record $MODID
End_installation
else
echo "未找到id信息无法安装"
fi
fi
rm -rf $Script_Dir &>/dev/null
fi


Unload
End_of_Frame_installation
