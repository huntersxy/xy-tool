#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Choice=1
File=/system/etc/hosts
. $Load AD-Hosts

TMPDIR=$Script_Dir

Delete_Frame_Dir() {
   rm -rf `ls | egrep -v 'module.prop|Write_Record.log|hosts.bak'`
}

Mount_system
ZIPFILE="$Download_File"
if [[ -f "$ZIPFILE" ]]; then
   [[ -d $Script_Dir ]] && rm -rf $Script_Dir &>/dev/null
   [[ ! -d $Script_Dir ]] && mkdir -p $Script_Dir
   echo "---------------------------------------------------------"
   unzip -ojq "$ZIPFILE" "install.sh" "module.prop" -d $Script_Dir
      if [[ -f $Script_Dir/module.prop ]]; then
         Name=$(grep_prop name $Script_Dir/module.prop)
         MODID=$(grep_prop id $Script_Dir/module.prop)
            if [[ -n $MODID ]]; then
               printf "开始安装$Name\n---------------------------------------------------------"
               echo "正在安装……"
               abi_Detection
               MODPATH=$Frame_Dir/$MODID
               File_bak=${MODPATH}/hosts.bak
               [[ ! -d $MODPATH ]] && mkdir -p $MODPATH
               unzip -oq "$ZIPFILE" -x "META-INF/*" "common/*" -d "$MODPATH" 2>/dev/null
                  if [[ ! -f $File_bak ]]; then
                     echo "开始备份源文件，成功备份后请不要格式化data数据否则源文件会删除，无法恢复默认"
                     cp -af $File $File_bak
                     if [[ $? = 0 ]]; then echo "源文件已备份至$File_bak"; else echo "备份失败，无法安装❌"; exit 1; fi
                  fi
                     set_perm $MODPATH/system/etc/hosts* 0 0 0600
                     End_installation
            else
               echo "未找到id信息无法安装"
            fi
      fi
   rm -rf $Script_Dir &>/dev/null
fi


Unload
End_of_Frame_installation