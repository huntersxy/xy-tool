#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


s() {
    echo 3
    sleep 1
    echo 2
    sleep 1
    echo 1
    sleep 1
}


echo "- 开始识别Magisk Manger包名……"
test -d /data/user_de/0/com.topjohnwu.magisk
    if [[ $? -eq 0 ]]; then
        Magisk_Manager=com.topjohnwu.magisk
    else
        echo "- 开始查找随机包名安装的Magisk Manger"
        t=`ls /data/user_de/*/*/shared_prefs/su_timeout.xml`
            if [[ $? -eq 0 ]]; then
                Magisk_Manager=`echo $t | cut -d / -f 5`
            else
                abort "！未识别到Magisk Manger包名"
            fi
    fi


echo "- 已识别到Magisk Manger包名为：$Magisk_Manager"

echo "- 检查是否存在多用户"

find /data/user_de/ -name "$Magisk_Manager" -type d | while read Dir; do
    user=`echo $Dir | cut -d / -f 4`
    File="$Dir/shared_prefs/${Magisk_Manager}_preferences.xml"
    am force-stop --user "$user" $Magisk_Manager

    ! test -f "$File" && {
        echo "- 未检测到数据开始启动Magisk Manger初始化数据"
        s
        am start --user "$user" -n `dumpsys package $Magisk_Manager | fgrep -B 2 'android.intent.category.LAUNCHER' | awk '/\//{print $2}'`
        s
        input keyevent 4
        am force-stop --user "$user" $Magisk_Manager
    }
    
    ! test -f "$File" && error "！加载数据出错" && continue
    
        echo "- 开始为$user用户修改自定义通道"
        sed -i '/update_channel/c\    <string name="update_channel">2<\/string>' "$File"
        fgrep -q '<string name="custom_channel">' "$File"
        if [[ $? -eq 0 ]]; then
        echo "- 正在编辑……"
        sed -i '/custom_channel/c\    <string name="custom_channel">https:\/\/gitee.com\/QingFeiDeiYi\/Magisk\/raw\/master\/stable.json<\/string>' "$File"
        else
        echo "- 正在写入数据……"
        sed -i '/<\/map>/i\    <string name="custom_channel">https:\/\/gitee.com\/QingFeiDeiYi\/Magisk\/raw\/master\/stable.json<\/string>' "$File"
        fi
done
echo "- 修改完毕，打开Magisk Manger即可看到效果"