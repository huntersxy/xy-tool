dumpsys battery | sed -e 's/Current Battery Service state/当前电池服务状态/' \
-e 's/AC powered/交流电源/' \
-e 's/USB powered/USB电源/' \
-e 's/Wireless powered/无线电源/' \
-e 's/Max charging current/最大充电电流/' \
-e 's/Max charging voltage/最大充电电压/' \
-e 's/status: 2/电池状态: 充电中/' \
-e 's/status: .*/电池状态: 未充电/' \
-e 's/health: 2/电池健康状态: 很好/' \
-e 's/health/电池健康状态/' \
-e 's/present/电池是否安装在机身/' \
-e 's/level/当前电量/' \
-e 's/scale/最大电量/' \
-e 's/voltage/当前电压/' \
-e 's/temperature/当前温度/' \
-e 's/current now/电流值，负数表示正在充电/' \
-e 's/technology/电池类型/' \
-e 's/true/真/g' \
-e 's/false/假/g'

