#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

lu=$PeiZhi_File/Immersion_style_Option
touch $lu
echo Immersion_style=$Immersion_style > $lu


No="apps,$NO"
if [[ -n $NO && -n $YES ]]; then
echo "俩个结果都存在变量，您不能同时选择隐藏和不隐藏内输入内容"
else

if [[ -n $NO && -z $YES ]]; then
echo "您选择了只在某些应用里不隐藏"
    if [ "$Immersion_style" = "1" ]; then
    echo "您选择了：［隐藏顶部状态栏]（底部虚拟键会显示），[且同时只在$NO包名应用里不隐藏］即将为您修改"
    echo $No
settings put global policy_control immersive.status=$No
sleep 3
    elif [ "$Immersion_style" = "2" ]; then
    echo "您选择了：［隐藏虚拟键]（顶部状态栏会显示，底部往上滑或者点击屏幕可以呼出来）且同时只在$NO［包名应用里不隐藏］即将为您修改"
settings put global policy_control immersive.navigation=$No
sleep 3
    elif [ "$Immersion_style" = "3" ]; then
    echo "您选择了：［隐藏虚拟键和顶部状态栏］且同时只在$NO［包名应用里不隐藏即将为您修改"
settings put global policy_control immersive.full=$No
    elif [ "$Immersion_style" = "4" ]; then
    echo "您选择了：［仅恢复顶部状态栏］即将为您恢复"
settings put global policy_control immersive.status=null
sleep 3
    elif [ "$Immersion_style" = "5" ]; then
    echo "您选择了：［仅恢复虚拟键］即将为您恢复"
settings put global policy_control immersive.navigation=null
sleep 3
    else
    echo "您选择了全部恢复默认，即将为您恢复"
settings put global policy_control null
    fi
else
echo

if [[ -z $NO && -n $YES ]]; then
echo "您选择了只需要在某些应用里隐藏"

else
echo

echo
echo

echo "俩个结果不存在变量，选择样式二风格无效，开始正常修改"
    if [ "$Immersion_style" = "1" ]; then
    echo "您选择了：［隐藏顶部状态栏（底部虚拟键会显示）］即将为您修改"
settings put global policy_control immersive.status=*
sleep 3
    elif [ "$Immersion_style" = "2" ]; then
    echo "您选择了：［隐藏虚拟键（顶部状态栏会显示，底部往上滑或者点击屏幕可以呼出来）］即将为您修改"
settings put global policy_control immersive.navigation=*
sleep 3
    elif [ "$Immersion_style" = "3" ]; then
    echo "您选择了：［隐藏虚拟键和顶部状态栏］即将为您修改"
settings put global policy_control immersive.full=*
    elif [ "$Immersion_style" = "4" ]; then
    echo "您选择了：［仅恢复顶部状态栏］即将为您恢复"
settings put global policy_control immersive.status=null
sleep 3
    elif [ "$Immersion_style" = "5" ]; then
    echo "您选择了：［仅恢复虚拟键］即将为您恢复"
settings put global policy_control immersive.navigation=null
sleep 3
    else
    echo "您选择了全部恢复默认，即将为您恢复"
settings put global policy_control null
    fi
fi
fi
fi