#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上，URL=https://www.lanzous.com/b0ez450d


Dir=$TMPDIR/bg
File=$Dir/res/drawable/splash.png
apk=`pm path Han.GJZS | sed 's/.*://'`


rm -rf $Dir
mkdir -p $Dir/res/drawable
cp -f "$BG" $File
cd $Dir
zip -r "$apk" ./*
rm -rf $Dir

am force-stop $Package_name && am start -n $Package_name/com.projectkr.shell.SplashActivity