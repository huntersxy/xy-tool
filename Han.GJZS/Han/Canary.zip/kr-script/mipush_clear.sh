#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

echo "- 清理中..."
cd /data/data
for i in `ls`; do
	rm -f $i/shared_prefs/mipush*.xml
done

echo "- 完成！"
sleep 0.3
