#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


cd $DATA_DIR/android/code_cache
echo "Actuator=$Actuator" >$ShellScript/Shell2.sh
echo "$CMD" >>$ShellScript/Shell2.sh

echo -e "当前输入的命令：\n"
tail -n +2 $ShellScript/Shell2.sh
echo -e "\n\n------------------------------------------------\n"
echo -e "执行结果：\n"

case $Actuator in
    source)
        . $ShellScript/Shell2.sh
        ;;
        
    sh)
        sh $ShellScript/Shell2.sh
        ;;
esac
