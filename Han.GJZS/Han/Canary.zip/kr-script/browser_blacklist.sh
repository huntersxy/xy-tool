#去除小米自带浏览器黑名单
#酷安@toolazy
rm -rf /data/data/com.android.browser/files/data/caclist/*
chmod 000 /data/data/com.android.browser/files/data/caclist 2>/dev/null
rm -rf /data/media/0/browser/MediaCache/*
chmod 000 /data/media/0/browser/MediaCache 2>/dev/null

echo "- 完成！"
sleep 0.3
