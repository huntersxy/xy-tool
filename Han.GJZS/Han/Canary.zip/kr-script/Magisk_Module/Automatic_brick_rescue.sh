#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


echo "Clean=$Clean" > $Data_Dir/$1.log
echo "Cache=$Cache" >> $Data_Dir/$1.log
echo "Frequency=$Frequency" >> $Data_Dir/$1.log
echo "Compulsory_Rescue=$Compulsory_Rescue" >> $Data_Dir/$1.log
echo "Set_Time=$Set_Time" >> $Data_Dir/$1.log
echo "Pattern=$Pattern" >> $Data_Dir/$1.log

if [[ `getprop init.svc.bootanim` != "stopped" ]]; then
   abort "！未支持您的设备请联系我适配，错误代码：`getprop init.svc.bootanim`"
fi

echo "$Set_Time" | egrep 'm|s' && abort "！设置的时间不能带单位，只允许数字和小数点"


mask -vc
mask $1
. $Load $1

[[ ! -d $Module ]] && mkdir -p $Module

#
cat <<Han >$Module_S2
#!/system/bin/sh
#本脚本由搞机助手自动创建，下载地址：https://www.coolapk.com/apk/Han.GJZS
#请不要试图篡改本脚本，否则一切后果自负，已安装版本：$version($versionCode)
#特别鸣谢：topjohnwu
#本模块需要Magisk提供服务支持


Modules_Dir=/data/adb/modules
MODPATH=\$Modules_Dir/$1
START_LOG=\$MODPATH/Number_of_starts.log
LOG=\$MODPATH/Number_of_brick_rescue.log
[[ -f \$LOG ]] && Number_of_brick_rescue=\`cat \$LOG\`
Module_XinXi=\$MODPATH/module.prop
export PATH="$PATH0"
Han

(
PATH="$PATH0"
if [[ -z `$which setenforce` ]]; then
   echo "- 检测到系统缺少命令，开始复制busybox"
   cp -f "$ELF2_Path/busybox" $Module
   chmod 755 $Module/busybox
cat <<Han >>$Module_S2
alias setenforce='$Module/busybox setenforce'
Han

fi
)

cat <<Han >>$Module_S2

if [[ ! -f \$START_LOG ]]; then
   echo 0 >"\$START_LOG"
   Frequency2=0
else
   Frequency=\`cat \$START_LOG\`
   Frequency2="\$((Frequency+1))"
   echo "\$Frequency2" >"\$START_LOG"
fi
Han


if [[ $Clean = 1 ]]; then
Choice0="如果在重启$Cache次后未成功开机自动自动清除系统包名缓存和关闭SELinux尝试一次开机操作"
cat <<Han >>$Module_S2
   if [[ \$Frequency2 -eq $Cache ]]; then
      rm -rf /data/system/package_cache/*
      echo 'setenforce 0' >"\$MODPATH/post-fs-data.sh"
      reboot
   elif [[ \$Frequency2 -ge $Frequency ]]; then
Han
else
Choice0="未设置自动清除系统包名缓存和关闭SELinux"
cat <<Han >>$Module_S2
   if [[ \$Frequency2 -ge $Frequency ]]; then
Han
fi


case "$Pattern" in
Core_model)
   if check_ab_device; then
      File=/data/cache/.disable_magisk
   else
      File=/cache/.disable_magisk
   fi

cat <<Han >>$Module_S2
      touch "$File"
Han
;;

Disable)
cat <<Han >>$Module_S2
      for i in \`ls \$Modules_Dir\`; do
         [[ "\$i" = "$1" ]] && continue
         touch "\$Modules_Dir/\$i/disable"
      done
Han
;;
esac



case "$Compulsory_Rescue" in
recovery)
Choice1="recovery"
cat <<Han >>$Module_S2
      rm -f "\$START_LOG"
      reboot recovery
   fi
Han
;;

fastboot)
Choice1="FASTBOOT"

cat <<Han >>$Module_S2
      rm -f "\$START_LOG"
      reboot bootloader
   fi
Han
;;

9008)
Choice1="9008"

cat <<Han >>$Module_S2
      rm -f "\$START_LOG"
      reboot edl
   fi
Han
;;
esac


case "$Pattern" in
Core_model)
Choice2="启用Magisk核心功能模式，请确定Magisk专区 --> 「一键修复部分系统在Magisk Manager里无法关闭核心模式」的开关识别状态是否跟Magisk Manger设置里「Magisk 核心功能模式」一致，如果识别错误请务必联系我修复，否则本模块将会无法开启Magisk核心功能模式！"
echo "- 已选择Magisk核心功能模式，仅启用核心功能，不加载任何模块。MagiskSU 和 MagiskHide 仍会持续运作"
   error "！$Choice2" | sed 's#启用Magisk核心功能模式，##'
;;

Disable)
Choice2="禁用所有模块"
;;

recovery)
Choice2="进入recovery模式"
;;

Security_mode)
Choice2="进入安全模式"
echo "- 在安全模式里只加载系统必要程序，系统之外的第三方程序或文件统统不会启动。需要退出安全模式，只要重启就可以退出"
;;

9008)
Choice2="进入9008模式"
;;

fastboot)
Choice2="进入FASTBOOT模式"
;;
esac


description="用途：当刷入一些模块导致无法正常开机，自动触发已设置的自动救砖操作方式：$Choice0，如果再无限重启$Frequency次后未开机强制自动救砖重启到$Choice1，正常启动等待$Set_Time分钟后没有开机自动$Choice2"


cat <<Han >>$Module_S2
      sleep ${Set_Time}m
      if [[ \`getprop init.svc.bootanim\` = "stopped" ]]; then
         rm -f "\$START_LOG" "\$MODPATH/post-fs-data.sh"
         if [[ -f \$LOG ]]; then
            sed -i "/^description=/c\description=$description，已为您自动救砖：\$Number_of_brick_rescue次。" "\$Module_XinXi"
         fi
      else
         if [[ ! -f \$LOG ]]; then
            echo "1" >\$LOG
         else
            p=\$((Number_of_brick_rescue+1))
            echo "\$p" >\$LOG
         fi
Han


case "$Pattern" in
Core_model)
cat <<Han >>$Module_S2
         touch "$File"
         reboot
      fi
Han
;;

Disable)
cat <<Han >>$Module_S2
            for i in \`ls \$Modules_Dir\`; do
               touch "\$Modules_Dir/\$i/disable"
            done
            reboot
      fi

Han
;;

recovery)
cat <<Han >>$Module_S2
         reboot recovery
      fi

Han
;;

Security_mode)
cat <<Han >>$Module_S2
         setprop persist.sys.safemode 1 && reboot
      fi

Han
;;

9008)
cat <<Han >>$Module_S2
         reboot edl
      fi

Han

;;

fastboot)
cat <<Han >>$Module_S2
         reboot bootloader
      fi

Han

;;
esac



printf "id=$1
name=$name
version=$version
versionCode=$versionCode
author=by Han　|　情非得已c
description=$description" >$Module_XinXi
[[ -f $Module_XinXi ]] && echo -e "\n- 「$name」模块已创建模块将在下次重启手机生效！"

echo "- 查看描述"
echo "- $description"