#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


ChongQi2=$ChongQi
ChongQi=0
Version=Stable
if [[ -d /data/data/com.solohsu.android.edxp.manager ]]; then abort -e "已检测到您安装了EdXposed Installer，由于作者没更新了导致无法检测到新版EDXposed，显示未安装！\n请卸载EdXposed Installer选择EdXposed_Manager才能继续安装"; fi
[[ -f /system/lib/libjit.so ]] && abort "！一山不容二虎，请先卸载太极 · 阳模块，再来安装EDXposed吧！"


AZ_EdXp_apk() {
    Download "$@"
    export File="$Download_File"
    if [[ -f $File ]]; then
        pm uninstall org.meowcat.edxposed.manager &>/dev/null
        echo "开始安装$3……"
        sh $ShellScript/install_apk.sh
    else
        error "下载$3失败❌"
    fi
}



if [[ $Riru = 1 ]]; then
    sh $install_MOD $Compatible $Error None 1 "riru-core"
fi
if [[ $SELinux_OFF = 1 ]]; then
    sh $install_MOD $Compatible $Error None 1 "SELinux_OFF"
fi

    if [[ $EdXp_Type -eq Custom ]]; then
        ZDY=1
    else
        if [[ $Version = Canary ]]; then
            if [[ $EdXp_Type -eq 1 ]]; then
                YAHFA=1
                echo "已选择Canary-YAHFA版EdXposed"
            elif [[ $EdXp_Type -eq 2 ]]; then
                echo "已选择Canary-SandHook版EdXposed"
                SandHook=1
            fi
        
        elif [[ $Version = Stable ]]; then
            if [[ $EdXp_Type -eq 1 ]]; then
                Stable_YAHFA=1
                echo "已选择稳定版YAHFA版EdXposed"
            elif [[ $EdXp_Type -eq 2 ]]; then
                echo "已选择稳定版SandHook版EdXposed"
                Stable_SandHook=1
            fi
        fi
    fi

apk2=$apk
apk=0
ChongQi=$ChongQi2

. $Load EdXposed



if [[ $ZDY -eq 1 ]]; then
    zip_File="$File"
else
    zip_File="$Download_File"
fi
    M=${zip_File##*/}
    if [[ -f "$zip_File" ]]; then
        [[ -d $Script_Dir ]] && rm -rf $Script_Dir &>/dev/null
        [[ ! -d $Script_Dir ]] && mkdir -p $Script_Dir
        echo "---------------------------------------------------------"
        echo "开始安装 $M……"
        unzip -ojq "$zip_File" "META-INF/*" "module.prop" -d $Script_Dir
        fgrep -q '#MAGISK' $jian2 && echo "$M是Magisk模块.zip" || { rm -rf $Script_Dir &>/dev/null; abort "$M不是Magisk模块.zip！无法刷入"; }
        
            if [[ -f $jian ]]; then
                if [[ -f $Script_Dir/module.prop ]]; then
                    Name=$(grep_prop name $Script_Dir/module.prop)
                    MODID=$(grep_prop id $Script_Dir/module.prop)
                        if [[ -n $MODID ]]; then
                            if [[ $ZDY = 1 ]]; then
                                case $MODID in
                                riru_edxposed) :;;
                                riru_edxposed_sandhook) :;;
                                *) abort "您选择的自定义模块文件不是EDXposed-Magisk文件，不允许被刷入，后会有期……886";;
                                esac
                            fi
                                echo "开始安装$Name模块"
                                echo "模块被安装在$Modules_Dir/$MODID"
                                echo "---------------------------------------------------------"
                                sh $install_MOD $Compatible $Error "$zip_File" 0
                        else
                            abort "未找到id信息无法安装"
                            ChongQi=0
                        fi
                fi
            else
                ChongQi=0
                error "${jian##*/} 脚本丢失，无法安装${M##/}该模块！"
            fi
            rm -rf $Script_Dir &>/dev/null
    fi
    sleep 2
    echo
    unset YAHFA SandHook Stable_YAHFA Stable_SandHook
    apk=$apk2
    . $Load EdXposed
CQ
