#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Find_prop() {
   sed -n "s/^$1=//p" $2
}

for i in `find "$Modules_Dir" -name module.prop`; do
   id=`Find_prop id $i`
   name=`Find_prop name $i`
   Size=`du -sh "$Modules_Dir/$id" 2>/dev/null | awk '{print $1}'`
   [[ -n $Size ]] && echo "$id|$name「大小：$Size」" || echo "$id|$name"
done
