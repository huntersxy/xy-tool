#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


mask -vc
mask $1

[[ -d $Module ]] && rm -rf $Module
echo "已找到的温控文件"

for i in `find /vendor -iname thermal* -type f`; do
echo "$i" | fgrep -iq 'android.' && continue
echo $i
   File_Dir="$Module/system${i%/*}"
   if [[ ! -d "$File_Dir" ]]; then
      mkdir -p "$File_Dir"
   fi
   touch "$Module/system$i"
done

   for o in `find /system -iname thermal* -type f`; do
   echo "$o" | fgrep -iq 'android.' && continue
   echo $o
      File_Dir2="${Module}${o%/*}"
      if [[ ! -d "$File_Dir2" ]]; then
         mkdir -p "$File_Dir2"
      fi
      touch "$Module$o"
   done

. $Load $1
printf "id=id
name=$name
version=$version
versionCode=$versionCode
author=$author
description=$description" >$Module_XinXi
[[ -f $Module_XinXi ]] && echo -e "\n- 「$name」模块已创建模块将在下次重启手机生效！" && CQ
