#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

ChongQi2=$ChongQi
ChongQi=0

if [[ $Riru = 1 ]]; then
   (
      Compatible=1
      sh $install_MOD $Compatible $Error None 1 "riru-core"
   )
fi
   if [[ ! -f "/data/misc/riru/api_version" ]]; then
      ui_print "*********************************************************"
      ui_print "！未安装Riru - Core 框架，安装失败！！！"
      abort "*********************************************************"
   elif [[ ! -d /data/data/moe.shizuku.redirectstorage ]]; then
      abort "！没有安装存储重定向应用，无法安装"
   fi


ChongQi=$ChongQi2
sh $install_MOD $Compatible $Error None 1 "riru_storage_redirect"
