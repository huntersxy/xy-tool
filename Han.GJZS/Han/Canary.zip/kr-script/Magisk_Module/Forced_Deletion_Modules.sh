#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


for i in $state; do
   [[ $i = Reboot ]] && ChongQi=1
   Module="$Modules_Dir/$i"
   [[ -f "$Module_us" ]] && sh "$Module_us"
   rm -rf $Module
   [[ $? = 0 ]] && echo "已删除模块：$i"
done

CQ