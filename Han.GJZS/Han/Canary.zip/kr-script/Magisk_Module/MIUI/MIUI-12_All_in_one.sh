#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


while read i
do
eval echo $i=\$$i >>"$Data_Dir/MIUI-12_All_in_one.log"
done<<Han
ChongQi
Installation_plan
Export_Directory
Theme_plan
Gesture_Background
Gesture_Return
XiaoBaiTiao
Han


Choice=1
. $Load MIUI-12_All_in_one
zipFile=$Download_File

[[ ! -f $zipFile ]] && abort "下载文件出错❌"

yasuo() {
    cd "$1"
    zip -rq "$2" ./*
}

Remove_suffix() {
    mv "$1".zip "$1"
}

JieYa_Theme() {
    echo "正在合并主题配置文件"
    unzip -p $lu/$1 'theme_values.xml' | sed 's/<\/MIUI_Theme_Values>/d' >$tf
    if [[ $? -ne 0 ]]; then
        error "当前应用的第三方主题配置文件里没有theme_values.xml文件，合并出错！"
    fi
}

XML_T() {
echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<MIUI_Theme_Values>" >$tf
}

Clean() {
rm -rf $1 &>/dev/null
mkdir -p $1
}


lu=$TMPDIR/system/media/theme/default

jian=$lu/framework-res
jian2=$lu/com.miui.home

# tlu=$TMPDIR/XiaoBaiTiao
tlu2=$TMPDIR/Return
tlu3=$TMPDIR/Background
tlu4=$TMPDIR/tmp
tlu5=$tlu4/res/drawable-440dpi-v4
tlu6=$tlu4/res/drawable-xxhdpi-v4
tlu7=$tlu4/res/drawable/


tf=$tlu4/theme_values.xml
tf2=$tlu4/nightmode/theme_values.xml
tf6=$TMPDIR/module.prop



Theme_Mo=/system/media/theme/default/
Theme_3=/data/system/theme/
Check_Theme0=`ls -l $Theme_Mo | grep ^- | wc -l`
Check_Theme3=`ls -l $Theme_3 | grep ^- | wc -l`



Clean $lu

echo "- 开始解压配置文件$File_Name"
unzip -oq "$zipFile" -d $TMPDIR

if [[ $Theme_plan == 1 ]]; then
    echo "- 开始执行合并方案修改，注：在当前应用的主题基础上修改，已搞机助手修改的优先生效！"
    if [[ $Check_Theme3 -ge 1 ]]; then
        Merge_Theme=true
        echo "- 已检测到您使用了第三方主题，开始从第三方主题上修改"
        for o in `find $Theme_3 -type f`;do
            cp -f $o $lu
        done
    elif [[ $Check_Theme0 -ge 1 ]]; then
        Merge_Theme=true
        echo "- 您没有使用第三方主题，开始使用从默认主题上修改"
        for o in `find $Theme_Mo -type f`;do
            cp -f $o $lu
        done
    fi
elif [[ $Theme_plan == 0 ]]; then
    Merge_Theme=false
    echo "- 已选择不合并主题方案修改，注：如果搞机助手不支持的修改的，剩下的没改的就全是系统默认的"
fi



printf "id=$id
version=$version
versionCode=$versionCode
name=$name
author=$author
description=已安装：" >$tf6



if [[ $XiaoBaiTiao -eq 1 ]]; then
    echo "- 已选择小白条沉浸"
    echo -n '小白条沉浸' >>$tf6
    Clean $tlu4
    $Merge_Theme && JieYa_Theme framework-res || XML_T
cat <<Han >>$tf
    <dimen name="navigation_bar_height">0dp</dimen>
    <dimen name="navigation_bar_height_landscape">0dp</dimen>
</MIUI_Theme_Values>
Han
    mkdir $tlu4/nightmode
    cp -f $tf $tf2
    yasuo $tlu4 $jian.zip
    Remove_suffix $jian
fi


if [[ $Gesture_Return != 0 || $Gesture_Background != 0 ]]; then
    Clean $tlu4
fi


if [[ $Gesture_Return = 0 ]]; then
    y=false
else
    y=true
    echo "- 开始安装边缘手势返回特效"
    echo -n '，边缘手势返回特效' >>$tf6
    for i in $tlu5 $tlu6 $tlu7; do
        mkdir -p $i
        cp -f $tlu2/$Gesture_Return/gesture_back_arrow.png $i
    done
fi

if [[ $Gesture_Background = 0 ]]; then
    y=false
else
    y=true
    echo "- 开始安装边缘手势背景特效"
    echo -n '，边缘手势背景特效' >>$tf6
    for i in $tlu5 $tlu6 $tlu7; do
        mkdir -p $i
        cp -f $tlu3/$Gesture_Background/gesture_back_background.png $i
    done
fi

if $y; then
    yasuo $tlu4 $jian2.zip
    Remove_suffix $jian2
fi


if [[ $Installation_plan == Magisk ]]; then
    MODPATH=$Modules_Dir/$id
    Module_XinXi=$MODPATH/module.prop
    
    echo "- 您已选择了方案①Magisk挂载方案"
    mask -vc
    echo "Powered by Magisk (@topjohnwu)"
    rm -rf $MODPATH
    mkdir -p $MODPATH
    cp -rf $TMPDIR/system $MODPATH
    cp -f $tf6 $Module_XinXi
    ui_print "----------------------------"
    echo "- 安装完成"
    echo "- 由于您选择的Magisk挂载方案，所以必须再重启后，然后去个性化主题里应用一遍默认主题才会生效"
    CQ
elif [[ $Installation_plan == mtz ]]; then
    [[ -n $Export_Directory ]] && lu2=`dirname $Export_Directory`
    echo "- 您已选择了方案②打包成.mtz主题"
    [[ -n $Export_Directory && ! -d $lu2 ]] && echo "输入目录不存在开始创建" && mkdir -p $lu12 && echo "创建成功，开始打包…………" || [[ -n $Export_Directory && -d $lu2 ]] && echo "输入的路径目录存在，开始打包…………" || [[ -z $Export_Directory ]] && echo "您没有自定义输出路径，将会导出到默认路径"
    cd $lu
    zip -rq ${Export_Directory:=$GJZS/搞机助手"$Time"}.mtz ./*
    cd $TMPDIR/mtz
    zip -rq ${Export_Directory:=$GJZS/搞机助手"$Time"}.mtz ./*
    echo -e "- 文件已打包到\n${Export_Directory:=$GJZS/搞机助手"$Time"}.mtz"
fi


#exit
# if [[ $DownloadProviderUi == 1 ]]; then
# echo "已选择去除下载管理热榜以及VIP下载"
# [[ ! -d $lu3 ]] && mkdir -p $lu3
# cp -rf -rf $jian $lu3
# echo -n "[下载管理热榜以及VIP下载];" >>$YiAZ
# fi



#隐藏导航栏无效
    # <dimen name="navigation_bar_width">0dp</dimen>
    # <dimen name="navigation_bar_height">0dp</dimen>
    # <dimen name="system_bar_height">0dp</dimen>
