#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


to_Module() {
mask -vc
mask $1
Choice=1
. $Load $1
wait

File="$Download_File"
if [[ -f "$File" ]]; then
if [[ ! -d $Module || $versionCode -lt $versionCode ]] ; then
rm -rf $Module
JC=`find $Modules_Dir -iname 'MiWallpaper.apk'`
[[ -n "$JC"  ]] && abort "已检测到相同类似模块，无法安装请先卸载后再来安装！"
echo "- 正在安装${name}-$version（$versionCode）……"
APK="$Module//system/app/MiWallpaper/MiWallpaper.apk"
mkdir -p $Module//system/app/MiWallpaper
cp -f $File $APK
mktouch $Module//system/app/MiWallpaper/oat/.replace


echo "id="$id"
name=Magisk版 "$name"
version="$version"
versionCode="$versionCode"
author="$author"
description=使用模块方式将「壁纸」替换成"$name"($versionCode)来达到使不支持超级壁纸的MIUI12使用超级壁纸功能。使用方法：从搞机助手MIUI专区可快速进入隐藏的超级壁纸功能" >$Module_XinXi

echo 'rm -rf /data/system/package_cache/*/MiWallpaper-*
rm -rf /data/system/package_cache/*/com.miui.miwallpaper-*' > $Module_us

cat <<Han >$Module_S2
#!/system/bin/sh

rm -rf /data/app/com.miui.miwallpaper-*
Han

if [[ -f $APK ]]; then
set_perm_recursive $Module 0 0 0755 0644
rm -rf /data/system/package_cache/*/MiWallpaper-*
rm -rf /data/system/package_cache/*/com.miui.miwallpaper-*
echo "- 「"$name"」Magisk模块创建完成，模块将在下次重启生效"
echo "- 已使用模块方式将「壁纸」替换成"$name"($versionCode)来达到使不支持超级壁纸的MIUI12使用超级壁纸功能，这样安装系统软件时也没必要去系统的文件管理器安装。使用方法：从搞机助手MIUI专区可快速进入隐藏的超级壁纸功能"
CQ
fi
elif [[ -d $Module && $versionCode -ge $versionCode ]]; then
echo "- 已安装了最新版本：${name}-$version（$versionCode），不再重复安装。"
fi
else
abort "文件下载错误❌"
fi
}

APK=`pm path "com.miui.miwallpaper" | sed 's/package://'`
test -d /data/app/com.miui.miwallpaper-* && abort -e "已检测到再/data/app/目录下安装了「壁纸」会导致模块不能生效，无法安装\nAPK路径：$APK\n请卸载更新还原系统初始版本"
to_Module MIUI_Wallpaper