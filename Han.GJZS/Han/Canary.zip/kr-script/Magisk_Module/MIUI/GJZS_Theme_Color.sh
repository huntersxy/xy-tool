#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Theme() {

XR() {
cat <<Han >>$Dir/theme_values.xml
<color name="$1">$2</color>
Han
   echo -n "[$3=$2]; " >>$Module_XinXi
}

[[ -d $Dir ]] && rm -rf $Dir &>/dev/null
[[ ! -d $Dir ]] && mkdir -p $Dir
Splash="${Splash:="$Splash2"}"


   if [[ -d $Module ]]; then
      rm -rf $Module
      mkdir -p $Module/$Theme_Mo
   else
      mkdir -p $Module/$Theme_Mo
   fi
   
printf "id=$1
name=自定义搞机助手主题配色
version=$Version_Name
versionCode=$Version_code
author=by：Han | 情非得已c
description=用途：自定义「搞机助手」主题：" >$Module_XinXi

cat <<Han >$Dir/theme_values.xml
<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<MIUI_Theme_Values>
Han
   [[ -n $colorAccent ]] && XR colorAccent $colorAccent 软件全局颜色
   [[ -n $log_basic ]] && XR kr_shell_log_basic $log_basic 脚本日志颜色
   [[ -n $log_error ]] && XR kr_shell_log_error $log_error 脚本执行错误颜色
   [[ -n $log_end ]] && XR kr_shell_log_end $log_end 脚本运行结束颜色
   [[ -n $Background_Transparency ]] && XR Background_Transparency $Background_Transparency 透明度
   [[ -n $Wave ]] && XR Wave $Wave 波浪颜色
cat <<Han >>$Dir/theme_values.xml
</MIUI_Theme_Values>
Han

   if [[ -f "$Splash" ]]; then
      echo "- 选择的`basename ${Splash}`图片存在开始设置为底图"
      mkdir -p "$Dir/res/drawable"
      cp "$Splash" "$Dir/res/drawable/splash.png"
      echo -n "[背景图片=`basename ${Splash}`]; " >>$Module_XinXi
   else
      error "- $Splash图片文件不错哦﻿⊙∀⊙！"
   fi
   
         if [[ -d $Dir ]]; then
            cd $Dir
            echo "- 开始压缩……"
            zip -r Han.GJZS ./*
         fi
}


mask $1

Theme_Mo=/system/media/theme/default
Dir=$TMPDIR/theme
Log=$Data_Dir/GJZS_Theme_Color.log
Module_File="$Module/$Theme_Mo/Han.GJZS"
tmp_File=$Module/update

[[ -f $Log ]] && rm $Log
while read i
do
eval echo $i=\$$i >>$Log
done<<Han
colorAccent
log_basic
log_error
log_end
params_view_bg
Background_Transparency
Wave
Splash
Splash2
Han


if [[ -f $Module_File ]]; then
   if [[ -f $tmp_File ]]; then
      abort "- 已经创建了模块请先重启手机再来配置"
   fi
      echo "- 已创建过模块开始执行直接生效"
      Theme $1
      mv -f $Dir/Han.GJZS "$Module_File"
      set_perm "$Module_File" 0 0 0644
      cp -fp "$Module_File" $Theme_Mo/Han.GJZS
      echo "- 即将在2秒后重启「搞机助手」"
      sleep 2
      am force-stop $Package_name && am start -n $Package_name/com.projectkr.shell.SplashActivity
else
   mask -vc   
   Theme $1
   
   cp -f $Dir/Han.GJZS $Module_File
   touch $tmp_File
   set_perm_recursive $Module 0 0 0755 0644
   
   [[ -d $Module ]] && echo "- 自定义搞机助手主题配色模块已创建成功，模块将在重启后生效，重启一次后以后无需每次重启，可以直接修改生效"
   
   CQ
fi

rm -rf $Dir
