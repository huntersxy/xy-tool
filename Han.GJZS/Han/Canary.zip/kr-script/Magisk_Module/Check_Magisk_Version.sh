#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Update_Magisk() {
mask -v
    if [[ "$MAGISK_VER_CODE" -lt "$8" ]]; then
echo "已检测到更新！最新版本为：$7($8)"
    elif [[ "$MAGISK_VER_CODE" -ge "$8" ]]; then
 echo "已是最新版本：$MAGISK_VER($MAGISK_VER_CODE)"
    fi
}

echo "做这个功能只是为了方便某些用户使用Magisk Manager下载缓慢且会下载失败"
[[ -f $Load ]] && . $Load Update_Magisk
