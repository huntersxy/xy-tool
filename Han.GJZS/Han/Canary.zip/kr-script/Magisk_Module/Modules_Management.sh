#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

Find_prop() {
   sed "/^$/d" "$Modules_Dir/$1/module.prop" | sed -n '/^name/p; /^id/p; /^version/p; /^versionCode/p; /^author/p; /^description/p' | sed 's/\&/\&#38;/g; s/\"/\&#34;/g; s/</\&#60;/g; s/>/\&#62;/g' | sed 's/^id=/&"/; s/^name=/&"/; s/^version=/&"/; s/^versionCode=/&"/; s/^author=/&"/; s/^description=/&"/; s/$/"/g'
}

List=0
K=0
M=0

for o in `ls $Modules_Dir`; do
   if [[ ! -f $Modules_Dir/$o/module.prop ]]; then
      K=$(($K+1))
      JG=1
      Empty_Modules_List[$List]="$o"
   else
      Modules_List[$List]="$o"
   fi
   List=$(($List+1))
done

cat <<Han
<?xml version="1.0" encoding="UTF-8" ?>
<group>
   <text>
     <slices>
       <slice size="18" color="#FFFF0000">已检测到您安装了$List个模块</slice>
     </slices>
   </text>
</group>
<group>
     <picker interruptible="false" reload="true" multiple="true" options-sh=". ./Magisk_Module/Get_Empty_Modules.sh" visible="echo $JG">
       <title>已检测到有$K个未提供信息的Magisk模块</title>
       <summary>点击可查看，并立即删除，切记此操作一旦执行无法恢复，请深思熟虑！！！</summary>
       <set>. ./Magisk_Module/Forced_Deletion_Modules.sh</set>
     </picker>
     <picker interruptible="false" reload="true" multiple="true" options-sh=". ./Magisk_Module/Get_Modules_List.sh" visible="[[ $List != 0 ]] &#38;&#38; echo 1">
       <title>强制删除模块</title>
       <summary>点击可查看，并强制删除(模块将在重启手机后失效)，切记此操作一旦执行无法恢复，请深思熟虑！！！</summary>
       <set>. ./Magisk_Module/Forced_Deletion_Modules.sh</set>
     </picker>
</group>
Han

   for i in "${Modules_List[@]}"; do
      M=$(($M+1))
      eval $(Find_prop $i)
cat <<Han
<group title="$M">
    <switch auto-off="true" confirm="true">
        <title>「$name」模块：卸载</title>
        <desc>关闭此开关为卸载模块，重启生效</desc>
        <getstate>. \$Module_remove_get '$id' '$name'</getstate>
        <setstate>. \$Module_remove_set '$id' '$name'</setstate>
    </switch>
    <switch auto-off="true" confirm="true">
        <title>禁用/启用</title>
        <desc>关闭此开关为禁用模块，重启生效</desc>
        <getstate>. \$Module_disabled_get '$id' '$name'</getstate>
        <setstate>. \$Module_disabled_set '$id' '$name'</setstate>
    </switch>
    <text>
       <slices>
         <slice break="true"></slice>
         <slice size="14" color="#FF9C27B0">模块信息如下：</slice>
         <slice break="true"></slice>
         <slice size="14" color="#FF0F9D58">
安装目录：$Modules_Dir/$id

版本：$version

版本号：$versionCode

作者：$author

说明描述：$description</slice>
       </slices>
    </text>
</group>
Han
   done
