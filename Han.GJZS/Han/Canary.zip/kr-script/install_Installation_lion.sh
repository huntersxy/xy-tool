#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


rm -rf /data/system/package_cache/*/*MiuiPackageInstaller*

case $Sound in
    uninstall)
    pm uninstall com.miui.packageinstaller
    ;;

    install)
    Choice=1
    . $Load $1
    
        File="$Download_File"
        
        if [[ -f "$File" ]]; then
            echo 0 >$Status
            pm uninstall org.meowcat.edxposed.manager &>/dev/null
            echo "开始安装$3……"
            sh $ShellScript/install_apk.sh &>/dev/null
            result=`cat $Status`
                if [[ $result -eq 0 ]]; then
                    echo "- 安装成功"
                    echo -e "- 注：无需在「安装狮 静默安装」里做任何设置，也不需要开启「安装狮-Root」模式授权ROOT权限\n，因为默认就可以使用「安装狮-DPM」来静默安装应用﻿"
                else
                    abort "！安装$3失败！请检查是否系统已核心破解"
                fi
        else
            abort "！下载$3文件出错"
        fi
    ;;
esac
