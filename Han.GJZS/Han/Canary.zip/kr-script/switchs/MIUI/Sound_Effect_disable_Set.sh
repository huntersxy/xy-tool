#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Mount_system &>/dev/null

if [[ $state == 1 ]]; then
	mv $audio/$1 $audio/${1}.bak
	cp -f $PeiZhi_File/mute.ogg $audio/$1
else
	mv $audio/${1}.bak $audio/$1
fi

chmod 644 $audio/$1 &>/dev/null
chown 0:0 $audio/$1 &>/dev/null
echo
Unload &>/dev/null
