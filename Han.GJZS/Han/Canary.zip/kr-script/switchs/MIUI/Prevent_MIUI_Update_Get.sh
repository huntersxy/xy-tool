#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

lu6=$SDdir/downloaded_rom

if [[ -f $lu6 ]]; then
echo 1
elif [[ ! -f $lu6 ]]; then
echo 0
fi