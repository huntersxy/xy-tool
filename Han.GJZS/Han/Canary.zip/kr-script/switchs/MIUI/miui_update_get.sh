#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

File=/system/etc/hosts
if [[ `cat $File | grep -ci update.miui.com` -ge 1 ]]; then
	echo 1
else
	echo 0
fi
