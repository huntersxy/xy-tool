#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

lu6=$SDdir/downloaded_rom

if [[ -d $lu6 || ! -d $lu6 && ! -f $lu6 ]]; then
[[ -d $lu6 ]] && rm -rf $lu6
touch $lu6 && chattr +i $lu6 && echo "已禁止了MIUI自动下载ROM"
elif [[ -f $lu6 ]]; then
chattr -i $lu6 && rm -rf $lu6 && echo "已恢复默认"
fi
sleep 1.2
