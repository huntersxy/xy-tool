#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Mount_system
File="$system/etc/hosts"
lu=/data/backup/HanShao
lu2="$lu/hosts"

if [[ $state == 1 ]]; then
[[ ! -f $lu2 ]] && cp -f $File $lu3 && echo "已备份hosts文件到：$lu2"
echo '127.0.0.1 update.miui.com' >>$File
echo "- [MIUI 更新检查] 已禁用！"
else
   for i in `find "$Modules_Dir" -name hosts`; do
      sed -i '/update.miui.com/d' $i
   done
   
      if [[ -f $lu2 ]]; then
         mv -f $lu2 $File && echo "- [MIUI 更新检查] 已恢复！"
         rmdir $lu &>/dev/null
      elif [[ ! -f $lu2 ]]; then
         echo "$lu2备份文件已经被你删除无法恢复"
         echo "开始启用方案②恢复MIUI更新检查"
         rm -rf $TMPDIR
         mkdir -p $TMPDIR
         cp -f $File $TMPDIR
         sed -i '/update.miui.com/d' $TMPDIR/hosts
         mv -f $TMPDIR/hosts $File
      fi
fi

pm clear com.android.updater &>/dev/null
chmod 644 $File
Unload
echo "- 如果刷新不出来就重启手机！"
sleep 2
