disabled=`pm list packages -d com.google.android.gms`
if [[ -n $disabled ]]; then
	echo 0
else
	echo 1
fi
