#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

mask $1

[[ ! -d $Module ]] && echo ""$2"模块未安装"

if [ $state == 1 ];then
rm -rf $Module_Remove &>/dev/null
[[ $? == 0 ]] && [[ -d $Module && ! -f $Module_Remove ]] && echo "「"$2"」模块将在下次重启不会被移除"
else
touch $Module_Remove &>/dev/null
[[ $? == 0 ]] && [[ -d $Module && -f $Module_Remove ]] && echo "「"$2"」模块将在下次重启后移除"
fi
sleep 1