#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Delete_Frame_File() {
jian=$Frame_Dir/$1/Write_Record.log

[[ ! -f $jian ]] && abort "已检测到您格式化过data数据，找不到写入记录文件，无法卸载"$2"框架服务！可重新安装获取写入记录文件"

for c in `cat $Frame_Dir/$1/Write_Record.log`; do
   echo "开始卸载"$2"框架"
   rm -f $c &>/dev/null
done
}

Delete_cache() {
if [[ -d /data/system/package_cache ]]; then
   rm -rf /data/system/package_cache
fi
}

if [[ $state = 0 ]]; then
   touch $Frame_Dir/$1/remove &>/dev/null
   [[ -f "$Frame_Dir/$1/uninstall.sh" ]] && sh "$Frame_Dir/$1/uninstall.sh"
else
   rm -rf $Frame_Dir/$1/remove &>/dev/null
fi


Mount_system
if [[ -f $Frame_Dir/riru-core/remove ]]; then
   mv -f $system/lib/libmemtrack_real.so $system/lib/libmemtrack.so
   mv -f $system/lib64/libmemtrack_real.so $system/lib64/libmemtrack.so

elif [[ -f $Frame_Dir/riru_edxposed/remove ]]; then
   Delete_Frame_File riru_edxposed "EDXposed-YAHFA"

elif [[ -f $Frame_Dir/riru_edxposed_sandhook/remove ]]; then
   Delete_Frame_File riru_edxposed_sandhook "EDXposed-SandHook"

elif [[ -f $Frame_Dir/riru_storage_redirect/remove ]]; then
   Delete_Frame_File riru_storage_redirect "存储重定向增强模式"

elif [[ -f $Frame_Dir/AD-Hosts/remove ]]; then
   mv -f $Frame_Dir/AD-Hosts/hosts.bak $system/etc/hosts

elif [[ -f $Frame_Dir/Fluid-NG/remove ]]; then
   pm uninstall --user 0 com.fb.fluid &>/dev/null
   pm uninstall com.fb.fluid &>/dev/null
   Delete_cache

elif [[ -f $Frame_Dir/Gesture/remove ]]; then
   pm uninstall --user 0 com.omarea.gesture &>/dev/null
   pm uninstall com.omarea.gesture &>/dev/null
   Delete_cache

fi

      rm -rf "$Frame_Dir/$1" &>/dev/null
      rmdir -p "$Frame_Dir" &>/dev/null
      sleep 2