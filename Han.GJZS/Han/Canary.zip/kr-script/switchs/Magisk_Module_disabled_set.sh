#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

mask $1

[[ ! -d $Module ]] && echo "「"$2"」模块未安装"

if [ $state == 1 ];then
rm -rf $Module_Disable &>/dev/null
[[ $? == 0 ]] && [[ -d $Module && ! -f $Module_Disable ]] && echo "「"$2"」模块将在下次重启后不会被禁用"
else
touch $Module_Disable &>/dev/null
[[ $? == 0 ]] && [[ -d $Module && -f $Module_Disable ]] && echo "「"$2"」模块将在下次重启后被禁用"
fi
sleep 1