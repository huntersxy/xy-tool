#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


if [[ $state == 1 ]]; then
   chattr +i "$1"
else
   chattr -i "$1"
fi
