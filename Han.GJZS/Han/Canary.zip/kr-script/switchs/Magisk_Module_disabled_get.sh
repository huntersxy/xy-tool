#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

mask $1

if [[ ! -d $Module ]]; then echo 0; exit 1; fi
   if [[ -f $Module_Disable ]]; then
      echo 0
   else
      echo 1
   fi
