#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


echo "当前设备架构为：$ABI"
echo
echo
if [[ -f /proc/cpuinfo ]]; then
echo "查看CPU详细信息"
echo "-------------------------------------"
cat /proc/cpuinfo
fi
 if [[ -f /proc/stat ]]; then
echo
echo
echo
echo "查看CPU占用"
echo "-------------------------------------"
cat /proc/stat
 fi