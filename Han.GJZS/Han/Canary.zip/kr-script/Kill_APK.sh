#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


echo 正在处理中请稍等……
stop=`pm list package -3`
echo "${stop//package:/am force-stop }"|sed -e '/com.tencent.qqpinyin/d' -e '/Han.GJZS/d' &>$ShellScript/StopAPK.sh
. $ShellScript/StopAPK.sh
echo "${stop//package:/已停止应用：}"|sed -e '/com.tencent.qqpinyin/d' -e '/Han.GJZS/d'
