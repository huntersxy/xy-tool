#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


ui_print "- 开始签名boot.img以防止twrp被覆盖"
tmp=$TMPDIR/boot.img
File="$img_File"
MultiFunction Magisk -sign "$img_File" "$tmp"
for i in $Subarea; do
echo "- 刷入刷写$i分区"
fastboot flash "$i" "$tmp"
done
rm -f "$tmp"
