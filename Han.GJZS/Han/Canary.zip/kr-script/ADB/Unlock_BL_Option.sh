1|①　使用fastboot oem unlook命令
2|②　使用fastboot oem unlook-go命令
3|③　使用fastboot flashing unlock命令
4|④　使用fastboot flashing unlock_critical命令
