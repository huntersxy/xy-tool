#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

echo "Lenovo|Lenovo联想系列"
echo "oppo|OPPO/一加/realme系列"
echo "Google_Pixel|Google Pixel系列"