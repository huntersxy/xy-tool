#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


if [[ $Scheme = 1 ]]; then
   if [[ -n "$Key" ]]; then
      fastboot oem unlook "$Key"
   else
      fastboot oem unlook
   fi

elif [[ $Scheme = 2 ]]; then
   if [[ -n "$Key" ]]; then
      fastboot oem unlook-go; fastboot oem unlook "$Key"
   else
      fastboot oem unlook-go; fastboot oem unlook
   fi

elif [[ $Scheme = 3 ]]; then
   if [[ -n "$Key" ]]; then
      fastboot flashing unlock "$Key"
   else
      fastboot flashing unlock
   fi

elif [[ $Scheme = 4 ]]; then
   if [[ -n "$Key" ]]; then
      fastboot flashing unlock_critical "$Key"
   else
      fastboot flashing unlock_critical
   fi
fi
exit 0