#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


File=$Data_Dir/Uninstalled_apk.log
sed -i 'd' $File
for i in `adb2 -c pm list packages -u`; do
echo "$i" >>$File
done
for i in `adb2 -c pm list packages`; do
sed -i "/$i/d" $File
done
sed -i 's/package://g' $File


cat $File