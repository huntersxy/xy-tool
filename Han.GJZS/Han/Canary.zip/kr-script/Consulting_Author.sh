#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

QQ=`pm list packages|grep com.tencent.mobileqq|wc -l`
Wechat=`pm list packages|grep com.tencent.mm|wc -l`


if [[ $QQ == 1 ]]; then
am start -n com.tencent.mobileqq/.activity.QQBrowserActivity --es url "https://wpa.qq.com/msgrd?v=3&uin=243454893"
elif [[ $Wechat == 1 ]]; then
am start -n com.tencent.mm/com.tencent.mm.plugin.webview.ui.tools.WebViewUI -d "http://wpa.qq.com/msgrd?v=3&uin=243454893"
fi