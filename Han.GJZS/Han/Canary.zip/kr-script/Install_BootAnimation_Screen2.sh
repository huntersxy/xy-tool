#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


case $Brand in
    nubia | Android_Default | Android_10)
        [[ $install_Way = system ]] && Mount_system
        [[ $install_Way = Module ]] && system=/system
    ;;
esac

lu=$PeiZhi_File/BootAnimation_Screen2
lu2=$lu/NOKIA_Music.mp3
PeiZhi_File=$lu
ZiDY_Screen2="${ZiDY_Screen2:=$ZiDY_Screen22}"

if [[ $Brand = Android_Default ]]; then
echo "已选择方案①"
jian=$system/media/bootanimation.zip
jian2=${jian}.bak
jian3=$system/media/bootaudio.mp3
jian4=${jian3}.bak
jian5=/system/media/bootanimation.zip.bak

elif [[ $Brand = Android_10 ]]; then
echo "已选择方案②"
jian=$system/product/media/bootanimation.zip
jian2=${jian}.bak
jian3=$system/product/media/bootaudio.mp3
jian4=${jian3}.bak
jian5=/system/product/media/bootanimation.zip.bak

elif [[ $Brand = nubia ]]; then
echo "已选择方案③"
jian=$system/media/theme/bootup/bootanimation.zip
jian2=${jian}.bak
jian3=$system/media/theme/bootup/bootaudio.mp3
jian4=${jian3}.bak
jian5=/system/media/theme/bootup/bootanimation.zip.bak

elif [[ $Brand = HuaWei ]]; then
echo "已选择方案④"
[[ $install_Way = Module ]] && abort "方案④不支持通过Magisk模块挂载"
GuaZai=/product
mount -o rw,remount $GuaZai
[[ -w /product ]] && echo "挂载读写成功" || abort "挂载读写失败"
jian=/product/etc/media/bootanimation.zip
jian2=${jian}.bak
jian3=/product/etc/media/bootaudio.mp3
jian4=${jian3}.bak
jian5=$jian2

elif [[ $Brand = horror ]]; then
echo "已选择方案⑤"
[[ $install_Way = Module ]] && abort "方案⑤不支持通过Magisk模块挂载"
GuaZai=/version
mount -o rw,remount $GuaZai
[[ -w /version ]] && echo "挂载读写成功" || abort "挂载读写失败"
jian=/version/special_cust/BLN-TL10C752/cmcc/cn/media/bootanimation.zip
jian2=${jian}.bak
jian3=/version/special_cust/BLN-TL10C752/cmcc/cn/media/bootaudio.mp3
jian4=${jian3}.bak
jian5=$jian2
fi


if [[ $Default == 1 ]]; then
echo "您选择了恢复默认"
if [[ -f $jian2 ]]; then
echo "开机动画备份文件存在，开始恢复"
mv -f $jian2 $jian
[[ $? = 0 ]] && echo "开机动画恢复成功"
else
echo "！开机动画备份文件已被删除无法恢复"
fi
echo
if [[ -f $jian4 ]]; then
echo "开机音乐备份文件存在，开始恢复"
mv -f $jian4 $jian3
[[ $? = 0 ]] && echo "开机动画音乐恢复成功"
else
echo "！开机音乐备份文件已丢失或者您的设备没有开机音乐"
fi
CQ
sleep 4
exit
fi

[[ ! -d $lu ]] && mkdir -p $lu


Backup() {
echo "正在备份第二屏中…………"
if [ ! -f "$jian2" ];then
echo "第二屏已自动备份"
mv -f $jian $jian2 >/dev/null 2>&1
echo "备份文件已保存到$jian5"
else
echo "第二屏备份已存在"
fi
echo "------------------------------------------------------"
if [ -f $jian3 ];then
echo "正在备份开机音乐中…………"
[[ -f $jian4 ]] && echo "开机音乐备份已存在"
else
[[ ! -f $jian3 ]] && echo "当前没有开机音乐"
fi
[[ ! -f $jian4 ]] && mv -f $jian3 $jian4 >/dev/null 2>&1 && echo "开机音乐已自动备份"
echo "------------------------------------------------------"
}

Magisk_Module() {
mask -vc
mask $1
MOD_id="$1"
MOD_name="开机动画第二屏"
Module_File=${Module}$jian
if [[ -d $Module ]]; then
rm -rf $Module
mkdir -p $Module
fi

mkdir -p `dirname $Module_File` &>/dev/null

if [[ $BootAnimation_Screen2 == NOKIA || $BootAnimation_Screen2 == NOKIABlack || $BootAnimation_Screen2 == Nokia_White2 ]]; then
echo "您选择了诺基亚系列，正在配置诺基亚开机音乐"
cp -f $lu2 ${Module}$jian3 &>/dev/null
fi
if [[ -f "$ZiDY_Screen2" ]]; then
cp -f "$ZiDY_Screen2" $Module_File
[[ $? = 0 ]] && echo "${ZiDY_Screen2##*/}动画已通过Magisk模块挂载"
else
cp -f $lu/${BootAnimation_Screen2}.zip $Module_File
fi
set_perm_recursive $Module 0 0 0755 $Authority

printf "id=$MOD_id
name=$MOD_name
version=1
versionCode=1
author=by：Han | 情非得已c
description=修改开机动画第二屏为$BootAnimation_Screen2" >$Module_XinXi
if [[ -f $Module_XinXi && -f $Module_File ]]; then
echo "「$MOD_name」Magisk模块创建完成，模块将在下次重启生效"
CQ
fi
}


if [[ -f $ZiDY_Screen2 ]]; then
if [[ $install_Way = Module ]]; then
echo "已选择通过Magisk模块挂载"
JC=`find $Modules_Dir -iname 'bootanimation.zip'`
[[ -n "$JC"  ]] && abort "已检测到存在相同的开机动画模块，存在冲突，无法安装！"
Magisk_Module BootAnimation_Screen2
elif [[ $install_Way = system ]]; then
JC=`find $Modules_Dir -iname 'bootanimation.zip'`
[[ -n "$JC"  ]] && abort "已检测到存在开机动画模块，无法安装！"
Backup
cp -f $ZiDY_Screen2 $jian >/dev/null && echo ${ZiDY_Screen2##*/}动画安装成功。 && Succeed=1
chmod $Authority $jian $jian3 &>/dev/null
Unload
[[ $Succeed = 1 ]] && CQ
sleep 3
exit 0
fi
fi



[[ $install_Way = system ]] && echo "即将开始备份……" && Backup
echo -e "您当前选择了$BootAnimation_Screen2开机动画"
eval "$BootAnimation_Screen2=1"

. $Load BootAnimation_Screen2
echo "开始安装……"
case $install_Way in
system)
if [[ $BootAnimation_Screen2 == NOKIA || $BootAnimation_Screen2 == NOKIABlack || $BootAnimation_Screen2 == Nokia_White2 ]]; then
echo "您选择了诺基亚系列，正在配置诺基亚开机音乐"
cp -f $lu2 $jian3 &>/dev/null
fi
;;
esac
if [[ -f $lu/${BootAnimation_Screen2}.zip && -d `dirname $jian` ]]; then
if [[ $install_Way = Module ]]; then
echo "已选择通过Magisk模块挂载"
Magisk_Module BootAnimation_Screen2
elif [[ $install_Way = system ]]; then
cp -f $lu/${BootAnimation_Screen2}.zip $jian
if [[ $? = 0 ]]; then
echo "$BootAnimation_Screen2第二屏开机动画已安装完成了，将在下次重启手机时生效。"
chmod $Authority $jian $jian3 >/dev/null 2>&1
case $Brand in
HuaWei | horror)
mount -o ro,remount $GuaZai &>/dev/null
;;

*)
Unload
;;
esac
CQ
else
echo "$BootAnimation_Screen2第二屏安装失败❌！！！"
fi
fi
elif [[ ! -d `dirname $jian` ]]; then
echo "`dirname $jian`开机动画第二屏路径不存在请尝试切换方案里的路径，如果没有请找我适配"
else
abort "文件下载失败无法安装！！！❌"
fi
