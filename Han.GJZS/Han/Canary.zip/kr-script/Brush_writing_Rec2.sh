#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

lu=`fgrep '/recovery|' "$Data_Dir/by_name.log" | sed 's/|.*//'`
IMG=${lu##*/}

IFS=$'\n'

if [[ -L $lu ]]; then
   echo "$IMG分区路径存在，开始检测刷入文件是否存在…………"
   echo
   if [[ -f "$Brush_in" ]]; then
      echo "$Brush_in刷入文件存在，开始刷入rec…………"
      dd if="$Brush_in" of="$lu"
   else
      echo "$Brush_in刷入文件都不存在，怎么刷？？？"
   fi
else
   error "$IMG分区路径不存在，刷入rec失败！"
fi

[[ -z "$IMG" ]] && exit 1
ui_print "- 开始签名boot.img以防止twrp被覆盖"

File=$EXECUTOR_PATH
for i in $IMG; do
MultiFunction Magisk -sign "$i" "$i"
done
