Magisk|ROOT系统
none|无