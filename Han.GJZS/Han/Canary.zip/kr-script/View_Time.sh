#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


echo 当前日期：`date +'%F  %p  %a'|sed -e 's/AM/上午/g' -e 's/PM/下午/g' -e 's/Mon/星期一/g' -e 's/Tue/星期二/g' -e 's/Wed/星期三/g' -e 's/Thu/星期四/g' -e 's/Fri/星期五/g' -e 's/Sat/星期六/g' -e 's/Sun/星期日/g'`
echo "即将查看时间刷新率"
for i in $(seq 3 -1 1); do
echo $i
sleep 1
done
echo "时间        毫秒"
until [[ $a == true ]]
do
m=`date +'%T %N'|cut -d ' ' -f 1`
ms=`date +'%S %N'|cut -d ' ' -f 2|cut -b 1-3`
echo "$m   ${ms}ms"
sleep $Delay
done
