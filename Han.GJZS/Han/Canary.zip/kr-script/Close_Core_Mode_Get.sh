#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


if [[ -f /cache/.disable_magisk ]]; then
echo "已开启Magisk 核心模式功能"
else
echo "已关闭Magisk 核心模式功能"
fi

echo "注释：默认会进行自动重启并生效"