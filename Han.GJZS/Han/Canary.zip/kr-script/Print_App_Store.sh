#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


chuli() {
  echo "$@" | sed -e 's/\&/\&#38;/g' -e 's/\"/\&#34;/g' -e 's/</\&#60;/g' -e 's/>/\&#62;/g'
}


start_xml() {
cat <<Han
<?xml version="1.0" encoding="UTF-8" ?>
<group>
    <text>
        <slices>
            <slice size="18" color="#FFFF0000">已云端上架了$H个应用</slice>
        </slices>
    </text>
    <text>
        <slices>
            <slice size="16" color="#FF9C27B0">本功能为云端收集一些其它常规应用商店没有的应用，如果你有好的应用想分享，或者你是应用作者，可私信我云端上架分享大家一起享用</slice>
            <slice break="true"></slice>
            <slice break="true"></slice>
            <slice size="16" color="#FF9C27B0">免责申明：&#x000A;一旦安装了本页应用，出现的一切后果请自行承担风险，与本人无关</slice>
        </slices>
    </text>
</group>

<group>
    <action auto-off="true" interruptible="false" reload="true">
        <title>刷新应用状态信息</title>
        <summary>用于刷新可更新、已/未安装应用，变动后的状态信息，因为自动刷新加载太久了</summary>
        <set>. ./Print_App_Store.sh -s</set>
    </action>
</group>

Han
}


title() {
cat <<Han
<group>
    <text>
        <slices>
            <slice size="14" color="#FFFF0000">$1</slice>
        </slices>
    </text>
Han
}


p() {
   . "$Load" "$1"
   name=`chuli "$name"`
   version=`chuli "$version"`
   author=`chuli "$author"`
   description=`chuli "$description"`
    if [[ $2 = -y ]]; then
        versionCode=`pm list packages --show-versioncode $1 | sed -n "s/.*$1 .*://p"`
    fi
cat <<Han
    <action interruptible="false" confirm="true">
        <title>$name</title>
        <desc>包名：$1&#x000A;版本：$version&#x000A;版本号：$versionCode&#x000A;作者：$author&#x000A;描述：$description&#x000A;更新于：$time</desc>
        <set>. ./install_App_Store_File.sh $1</set>
    </action>
Han
}

end() {
   echo -e '</group>\n'
}



###
xml="$Pages/App_Store.XML"
File="$Data_Dir/App_Store_version.log"
[[ -f $File ]] && user_version=`cat $File` || user_version=0
eval `sed -n 3p $Load`

if [[ $1 = -s ]]; then
   echo "正在刷新页面信息状态，请骚等……"
elif [[ ! -f $xml ]]; then
   :
elif [[ $user_version -eq $App_Store_version ]]; then
   exit 0
fi


exec 1>$xml
APK_ID=($(sed -n 's/^apk=//p' $Load | tr -d \'))


H=0
for i in ${APK_ID[@]}; do
H=$(($H+1))
      if [[ -n `pm path $i` ]]; then
         install_apk[$H]=$i
         user_versionCode=`pm list packages --show-versioncode $i | sed -n "s/.*$i .*://p"`
         . "$Load" "$i"
         [[ "$user_versionCode" -lt "$versionCode" ]] && update_apk[$H]=$i && unset install_apk[$H]
      else
         noinstall_apk[$H]=$i
      fi
done


echo $App_Store_version >$File
start_xml


if [[ -n ${update_apk[@]} ]]; then
   title "有更新（${#update_apk[@]}）"
   for i in ${update_apk[@]}; do
      p "$i"
   done
   end
fi
   if [[ -n ${install_apk[@]} ]]; then
      title "已安装（${#install_apk[@]}）"
      for o in ${install_apk[@]}; do
         p "$o" -y
      done
      end
   fi
      if [[ -n ${noinstall_apk[@]} ]]; then
         title "未安装（${#noinstall_apk[@]}）"
         for p in ${noinstall_apk[@]}; do
            p "$p"
         done
         end
      fi
         if [[ $H = 0 ]]; then
            title "未找到云端数据"
            end
            exit 1
         fi

         exit 0
