#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Choice=1
. $Load Zipsigner
    unzip -oq "$Download_File" -d "$ELF1_Path"
    chmod 755 $ELF1_Path/*


File="${File:="$File2"}"
File1=${File%.*}
File2=${File##*.}
File3="${File1}_sign.$File2"
echo "签名中请骚等，速度看文件大小而定……"
zipsigner "$File" "$File3"
    if [[ $? = 0 ]]; then
        echo "文件已保存到：$File3"
        return 0
    else
        error "签名$File失败"
        return 1
    fi