#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


[[ -f /system/lib/libjit.so ]] && abort "！一山不容二虎，请先卸载太极 · 阳模块，再来修复吧！"
[[ ! -d $DATA_DIR/org.meowcat.edxposed.manager ]] && abort "！未安装EdXposed Manager无法进行修复"
apk=1


AZ_EdXp_apk() {
    Download "$@"
    wait
    export File="$Download_File"
    if [[ -f $File ]]; then
        echo 0 >$Status
        pm uninstall org.meowcat.edxposed.manager &>/dev/null
        echo "开始修复……"
        sh $ShellScript/install_apk.sh &>/dev/null
        result=`cat $Status`
        [[ $result -eq 0 ]] && echo "- 修复成功" || abort "！修复失败"
    else
        error "下载$3失败❌"
    fi
}

. $Load EdXposed
