#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


if [[ -n $Set_the_time ]]; then
echo "已设置时间延迟$Set_the_time"
for i in $(seq $Set_the_time -1 1); do
echo "$i"
sleep 1
done
echo "开始截图"
  if [[ -z $SetLu ]]; then
echo "截图已保存到默认路径$GJZS目录下"
screencap -p $GJZS/ScreenShot_$Time.png
sleep 3
return
  elif [[ -n $SetLu ]]; then
echo "已自定义输出路径为$SetLu，检查$SetLu路径是否存在"
 if [[ -d $SetLu ]]; then
echo "路径存在开始截图"
screencap -p $SetLu/ScreenShot_$Time.png
sleep 3
else
echo "您输入的路径不存在，请重新输入"
 fi
  fi
elif [[ -z $Set_the_time ]]; then
echo "开始截图"
  if [[ -z $SetLu ]]; then
echo "截图已保存到默认路径$GJZS目录下"
screencap -p $GJZS/ScreenShot_$Time.png
sleep 3
return
  elif [[ -n $SetLu ]]; then
echo "已自定义输出路径为$SetLu，检查$SetLu路径是否存在"
 if [[ -d $SetLu ]]; then
echo "路径存在开始截图"
screencap -p $SetLu/ScreenShot_$Time.png
sleep 3
else
echo "您输入的路径不存在，请重新输入"
 fi
  fi
fi