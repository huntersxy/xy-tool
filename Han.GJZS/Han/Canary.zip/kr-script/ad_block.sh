#脚本来源于酷安@toolazy 、请关注微信订阅号“关注米柚更新”，未经授权，请勿转载 ！
#去除个性主题详情页广告
rm -rf /data/data/com.android.thememanager/files/cache/*
chmod 000 /data/data/com.android.thememanager/files/cache 2>/dev/null

#去除小米浏览器banner广告
rm -rf /data/data/com.android.browser/files/data/banners/*
chmod 000 /data/data/com.android.browser/files/data/banners 2>/dev/null

#去除小米浏览器热门搜索推荐
rm -rf /data/data/com.android.browser/files/data/kw1/*
rm -rf /data/data/com.android.browser/files/data/kw2/*
rm -rf /data/data/com.android.browser/files/data/kw3/*
chmod 000 /data/data/com.android.browser/files/data/kw1 2>/dev/null
chmod 000 /data/data/com.android.browser/files/data/kw2 2>/dev/null
chmod 000 /data/data/com.android.browser/files/data/kw3 2>/dev/null

#去游戏加速首页信息流广告
cd /data/data/com.miui.securitycenter/files/gamebooster
echo " " > gbintlgamewall
echo " " > gbviewpoints
chmod 000 gbintlgamewall
chmod 000 gbviewpoints

#去除部分系统App开屏广告
rm -rf /data/media/0/miad/*
chmod 000 /data/media/0/miad 2>/dev/null

# 安全中心广告
echo " " > /data/data/com.miui.securitycenter/files/securityscan_homelist_cache
chmod 000 /data/data/com.miui.securitycenter/files/securityscan_homelist_cache

echo "- 完成！"
sleep 0.5
