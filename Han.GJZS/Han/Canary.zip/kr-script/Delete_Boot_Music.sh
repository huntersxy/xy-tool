#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上

Mount_system

if [[ -f /system/media/bootanimation.zip ]]; then
jian3=$system/media/bootaudio.mp3
jian4=$system/media/bootaudio.mp3.bak
[[ -f $jian3 ]] && rm -rf $jian3 $jian4 && echo "删除成功" || { [[ ! -f $jian3 ]] && echo "您手机没有开机音乐文件"; }
fi

if [[ -f /product/etc/media/bootanimation.zip ]]; then
mount -o rw,remount /product
jian3=/product/etc/media/bootaudio.mp3
jian4=/product/etc/media/bootaudio.mp3.bak
[[ -f $jian3 ]] && rm -rf $jian3 $jian4 && echo "删除成功" || { [[ ! -f $jian3 ]] && echo "您手机没有开机音乐文件"; }
fi

if [[ -f /system/product/media/bootanimation.zip ]]; then
jian3=$system/product/media/bootaudio.mp3
jian4=$system/product/media/bootaudio.mp3.bak
[[ -f $jian3 ]] && rm -rf $jian3 $jian4 && echo "删除成功" || { [[ ! -f $jian3 ]] && echo "您手机没有开机音乐文件"; }
fi

Unload
sleep 2
