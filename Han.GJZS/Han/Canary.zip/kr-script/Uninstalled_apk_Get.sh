#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上




a() {
pm list packages -u
pm list packages -e
}

a | sort | uniq -u | cut -f2 -d ':'
exit


File=$Data_Dir/Uninstalled_apk.log
pm list packages -u >$File
done
for i in `pm list packages`; do
sed -i "/$i/d" $File
done
sed -i 's/package://g' $File


cat $File