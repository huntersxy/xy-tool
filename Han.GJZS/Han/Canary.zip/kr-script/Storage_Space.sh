#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


if [[ $KB1000 == 1 && $KB1024 == 1 && $B == 1 ]]; then
echo -e  "同时勾选：\n「已1KB=1000B格式查看」\n「已1KB=1024B格式查看」\n「已B格式单位查看」\n你是想闹哪样？？？"
exit
elif [[ $KB1000 == 1 && $KB1000 == 1 ]]; then
echo -e "同时勾选：\n「已1KB=1000B格式查看」\n「已1KB=1024B格式查看」\n你是想闹哪样？？？"
elif [[ $KB1000 == 1 && $B == 1 ]]; then
echo -e "同时勾选：\n「已1KB=1000B格式查看」\n「已B格式单位查看」\n你是想闹哪样？？？"
exit
elif [[ $KB1024 == 1 && $B == 1 ]]; then
echo -e "同时勾选：\n「已1KB=1024B格式查看」\n「已B格式单位查看」\n你是想闹哪样？？？"
exit
elif [[ $All == 1 && $KB1000 == 1 ]]; then
df -aH
elif [[ $All == 1 && $KB1024 == 1 ]]; then
df -ah
elif [[ $All == 1 && $b == 1 || $All == 1 ]]; then
df -a
elif [[ $KB1000 == 1 ]]; then
df -H
elif [[ $KB1024 == 1 ]]; then
df -h
elif [[ $B == 1 ]]; then
df
fi
