. ./Block_Device_Name.sh -None

grep '/boot' "$Data_Dir/by_name.log"