#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


PREFIX=$DATA_DIR/com.termux/files/usr/etc


HuiFu() {
sed -i '/mirrors.tuna.tsinghua.edu.cn/d' "$1"
sed -i 's/^#deb/deb/' "$1"
}


if [[ $Option = 1 ]]; then
Termux=`pm list packages -U com.termux | cut -d : -f 3`

    case $Termux in
    10*)
        echo "- 已识别到Termux UID为：$Termux"
        User_Group=$Termux
    ;;
    
    *)
        abort "！未知的UID：$Termux"
    ;;
    esac

if [[ ! -f $PREFIX/apt/sources.list ]]; then
mktouch $PREFIX/apt/sources.list
cat <<Han >$PREFIX/apt/sources.list
# The main termux repository:
#deb https://termux.org/packages/ stable main
deb https://mirrors.tuna.tsinghua.edu.cn/termux/termux-packages-24 stable main
Han
cp -f $PREFIX/apt/sources.list $PREFIX/apt/sources.list.dpkg-old
else
fgrep -q 'https://mirrors.tuna.tsinghua.edu.cn/termux/termux-packages-24' $PREFIX/apt/sources.list
[[ $? -ne 0 ]] && sed -i 's@^\(deb.*stable main\)$@#\1\ndeb https://mirrors.tuna.tsinghua.edu.cn/termux/termux-packages-24 stable main@' $PREFIX/apt/sources.list && cp -f $PREFIX/apt/sources.list $PREFIX/apt/sources.list.dpkg-old
fi

if [[ ! -f $PREFIX/apt/sources.list.d/game.list ]]; then
mktouch $PREFIX/apt/sources.list.d/game.list
cat <<Han >$PREFIX/apt/sources.list.d/game.list
# The main termux repository:
#deb https://dl.bintray.com/grimler/game-packages-24 games stable
deb https://mirrors.tuna.tsinghua.edu.cn/termux/game-packages-24 games stable
Han
else
fgrep -q 'https://mirrors.tuna.tsinghua.edu.cn/termux/termux-packages-24' $PREFIX/apt/sources.list.d/game.list
[[ $? -ne 0 ]] && sed -i 's@^\(deb.*games stable\)$@#\1\ndeb https://mirrors.tuna.tsinghua.edu.cn/termux/game-packages-24 games stable@' $PREFIX/apt/sources.list.d/game.list
fi

if [[ ! -f $PREFIX/apt/sources.list.d/science.list ]]; then
mktouch $PREFIX/apt/sources.list.d/science.list
cat <<Han >$PREFIX/apt/sources.list.d/science.list
# The main termux repository:
#deb https://dl.bintray.com/grimler/science-packages-24 science stable
deb https://mirrors.tuna.tsinghua.edu.cn/termux/science-packages-24 science stable
Han
else
fgrep -q 'https://mirrors.tuna.tsinghua.edu.cn/termux/termux-packages-24' $PREFIX/apt/sources.list.d/science.list
[[ $? -ne 0 ]] && sed -i 's@^\(deb.*science stable\)$@#\1\ndeb https://mirrors.tuna.tsinghua.edu.cn/termux/science-packages-24 science stable@' $PREFIX/apt/sources.list.d/science.list
fi

    chown $User_Group:$User_Group $PREFIX/apt $PREFIX/apt/sources.list.d $PREFIX/apt/sources.list $PREFIX/apt/sources.list.dpkg-old $PREFIX/apt/sources.list.d/science.list $PREFIX/apt/sources.list.d/game.list
    chmod 600 $PREFIX/apt/sources.list $PREFIX/apt/sources.list.dpkg-old $PREFIX/apt/sources.list.d/science.list $PREFIX/apt/sources.list.d/game.list
    chmod 700 $PREFIX/apt $PREFIX/apt/sources.list.d
    echo "- 已更换了清华源"
elif [[ $Option = clear ]]; then
    pm clear com.termux
    echo "- 已清除Termux全部数据来恢复了默认"
    exit 0
elif [[ $Option = 0 ]]; then
    HuiFu $PREFIX/apt/sources.list
    HuiFu $PREFIX/apt/sources.list.d/game.list
    HuiFu $PREFIX/apt/sources.list.d/science.list
    echo "- 已恢复了默认"
fi
    echo "- 请手动打开Termux然后执行一遍更新所有包"
    echo "- apt update && apt upgrade"
    echo "- 不过执行完「 apt update && apt upgrade 」会再次变回官方源，可再次更换清华源即可"
    
