#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


Termux=$DATA_DIR/com.termux
File=$Termux/files/home/.termux/termux.properties

if [[ $Option = 1 ]]; then
UID=`pm list packages -U com.termux | cut -d : -f 3`

    case $UID in
    10*)
        echo "- 已识别到Termux UID为：$UID"
        User_Group=$UID
    ;;
    
    *)
        abort "！未知的UID：$UID"
    ;;
    esac

   mktouch $File
cat <<EOF >$File
extra-keys = [['exit','/','-','HOME','UP','END','PGUP'],['TAB','CTRL','ALT','LEFT','DOWN','RIGHT','PGDN']]
EOF
   
   chmod 700 $Termux/files/home/.termux
   chown $User_Group:$User_Group $Termux/files/home/.termux $File
   chmod 644 $File
   echo "- 已添加双行快捷键，请手动重启Termux即可"
elif [[ $Option = 0 ]]; then
   rm -rf $File
   rmdir -p $Termux/files/home/.termux &>/dev/null
   echo "- 已恢复了默认，请手动重启Termux即可"
fi